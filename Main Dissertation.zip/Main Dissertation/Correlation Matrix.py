import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

# Load data
X_train = pd.read_csv('/Users/henriette/Desktop/Dissertation/Data/X_train_exp3.csv')

# Calculate correlation matrix
correlation_matrix = X_train.corr()

# Visualize
plt.figure(figsize=(16, 14))
sns.heatmap(correlation_matrix, annot=True, fmt='.2f', cmap='RdBu_r', 
            center=0, vmin=-1, vmax=1, square=True, linewidths=0.5)
plt.title('Feature Correlation Matrix - Experiment 3', fontsize=16, fontweight='bold')
plt.tight_layout()
plt.savefig('/Users/henriette/Desktop/Dissertation/Results/correlation_matrix_exp3.png', 
            dpi=300, bbox_inches='tight')
plt.show()

# Find highly correlated pairs (correlation > 0.8)
print("\nHIGHLY CORRELATED FEATURE PAIRS (r > 0.8):")
print("="*70)

high_corr_pairs = []
for i in range(len(correlation_matrix.columns)):
    for j in range(i+1, len(correlation_matrix.columns)):
        if abs(correlation_matrix.iloc[i, j]) > 0.8:
            high_corr_pairs.append({
                'Feature 1': correlation_matrix.columns[i],
                'Feature 2': correlation_matrix.columns[j],
                'Correlation': correlation_matrix.iloc[i, j]
            })

corr_df = pd.DataFrame(high_corr_pairs).sort_values('Correlation', ascending=False, key=abs)
print(corr_df.to_string(index=False))

# Find moderately correlated pairs (0.6 < r < 0.8)
print("\n\nMODERATELY CORRELATED FEATURE PAIRS (0.6 < r < 0.8):")
print("="*70)

mod_corr_pairs = []
for i in range(len(correlation_matrix.columns)):
    for j in range(i+1, len(correlation_matrix.columns)):
        corr_val = abs(correlation_matrix.iloc[i, j])
        if 0.6 < corr_val <= 0.8:
            mod_corr_pairs.append({
                'Feature 1': correlation_matrix.columns[i],
                'Feature 2': correlation_matrix.columns[j],
                'Correlation': correlation_matrix.iloc[i, j]
            })

mod_corr_df = pd.DataFrame(mod_corr_pairs).sort_values('Correlation', ascending=False, key=abs)
print(mod_corr_df.to_string(index=False))

print("\n" + "="*70)
print(f"Total feature pairs: {len(X_train.columns) * (len(X_train.columns)-1) // 2}")
print(f"High correlation pairs (>0.8): {len(high_corr_pairs)}")
print(f"Moderate correlation pairs (0.6-0.8): {len(mod_corr_pairs)}")
print("="*70)