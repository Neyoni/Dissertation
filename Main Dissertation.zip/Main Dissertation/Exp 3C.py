# ============================================
# EXPERIMENT 3C: XGBOOST LR-COEFFICIENT FEATURE SELECTION
# LR coefficients → Domain filter → SMOTE-ENN → XGBoost
# Using XGBoost instead of RF for fair comparison with Exp 3
# ============================================

import numpy as np
import pandas as pd
from xgboost import XGBClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import StratifiedKFold
from imblearn.combine import SMOTEENN
from sklearn.metrics import (f1_score, precision_score, recall_score, 
                             roc_auc_score, matthews_corrcoef, 
                             confusion_matrix, precision_recall_curve)
import matplotlib.pyplot as plt
from datetime import datetime
import json
import optuna
import warnings
warnings.filterwarnings('ignore')

print('='*70)
print("EXPERIMENT 3C: XGBOOST LR-COEFFICIENT FEATURE SELECTION")
print("LR Coefficients → Domain Filter → SMOTE-ENN → XGBoost")
print("Using XGBoost for fair comparison with Exp 3 best model")
print('='*70)

# ============================================
# STEP 1: LOAD DATA
# ============================================
print('\n[STEP 1/11] Loading data...')

X_train_full = pd.read_csv('/Users/henriette/Desktop/Dissertation/Data/X_train_exp3.csv')
X_test_full = pd.read_csv('/Users/henriette/Desktop/Dissertation/Data/X_test_exp3.csv')
y_train = pd.read_csv('/Users/henriette/Desktop/Dissertation/Data/y_train_exp3.csv').squeeze()
y_test = pd.read_csv('/Users/henriette/Desktop/Dissertation/Data/y_test_exp3.csv').squeeze()

print(f' Training: {X_train_full.shape[0]:,} samples, {X_train_full.shape[1]} features')
print(f' Test: {X_test_full.shape[0]:,} samples')
print(f' Starting with all 23 engineered features')

# ============================================
# STEP 2: SCALE FEATURES
# ============================================
print('\n[STEP 2/11] Scaling features...')

scaler = MinMaxScaler()
X_train_scaled = pd.DataFrame(
    scaler.fit_transform(X_train_full), 
    columns=X_train_full.columns,
    index=X_train_full.index
)
X_test_scaled = pd.DataFrame(
    scaler.transform(X_test_full), 
    columns=X_test_full.columns,
    index=X_test_full.index
)

print(' MinMaxScaler applied')

# ============================================
# STEP 3: TRAIN LOGISTIC REGRESSION (IMBALANCED DATA)
# ============================================
print('\n Training Logistic Regression on imbalanced data')
print('(Using class_weight="balanced" to handle 0.13% fraud rate)')

lr_selector = LogisticRegression(
    C=0.1,
    penalty='l2',
    solver='saga',
    max_iter=1000,
    class_weight='balanced',
    random_state=42,
    n_jobs=4
)

lr_start = datetime.now()
lr_selector.fit(X_train_scaled, y_train)
lr_time = (datetime.now() - lr_start).total_seconds()

print(f' LR trained: {lr_time:.1f}s')

# ============================================
# STEP 4: ANALYZE LR COEFFICIENTS
# ============================================
print('\nAnalyzing LR coefficients')

lr_coefs = pd.DataFrame({
    'feature': X_train_scaled.columns,
    'coefficient': lr_selector.coef_[0],
    'abs_coefficient': np.abs(lr_selector.coef_[0])
}).sort_values('abs_coefficient', ascending=False)

print('\nLogistic Regression Coefficients (sorted by absolute value):')
print(lr_coefs.to_string(index=False))

# Quick test performance
y_train_pred = lr_selector.predict(X_train_scaled)
y_test_pred = lr_selector.predict(X_test_scaled)

train_f1 = f1_score(y_train, y_train_pred)
test_f1 = f1_score(y_test, y_test_pred)

print(f'\nLR Performance (all 23 features):')
print(f'  Train F1: {train_f1:.4f}')
print(f'  Test F1:  {test_f1:.4f}')

# ============================================
# STEP 5: FEATURE SELECTION STRATEGY
# ============================================
print('\n Feature selection strategy')
print('\nApproach: Combine LR coefficients with domain knowledge')

# Strategy: Domain-critical features (MUST keep)
domain_critical = [
    'amount',
    'type_TRANSFER', 
    'type_CASH_OUT',
    'type_PAYMENT',
    'type_CASH_IN',
    'cashout_amount',
    'transfer_amount'
]

print(f'\nDomain-critical features (fraud-relevant):')
for feat in domain_critical:
    if feat in X_train_scaled.columns:
        coef = lr_coefs[lr_coefs['feature']==feat]['coefficient'].values[0]
        print(f'  {feat:25s}: {coef:+.4f}')

# Combine domain-critical + top temporal/behavioral features
selected_features = []

# Always include domain-critical
for feat in domain_critical:
    if feat in X_train_scaled.columns:
        selected_features.append(feat)

# Add top temporal features
temporal_features = ['hour_of_day', 'is_night', 'day_of_week', 'is_weekend']
for feat in temporal_features:
    if feat in X_train_scaled.columns and feat not in selected_features:
        selected_features.append(feat)
        
# Add top behavioral features
behavioral_features = ['is_round_amount', 'is_large_amount', 'is_extreme_amount', 
                       'is_small_amount', 'suspicious_combo']
for feat in behavioral_features:
    if feat in X_train_scaled.columns and feat not in selected_features and len(selected_features) < 12:
        selected_features.append(feat)

# Limit to top 10-12 features
selected_features = selected_features[:12]

print(f'\n FINAL SELECTED FEATURES ({len(selected_features)}):')
for i, feat in enumerate(selected_features, 1):
    if feat in lr_coefs['feature'].values:
        coef = lr_coefs[lr_coefs['feature']==feat]['coefficient'].values[0]
        rank = lr_coefs[lr_coefs['feature']==feat].index[0] + 1
        print(f'  {i:2d}. {feat:25s}: coef={coef:+.4f}, rank={rank:2d}/23')

# Filter to selected features
X_train_selected = X_train_scaled[selected_features].copy()
X_test_selected = X_test_scaled[selected_features].copy()

# ============================================
# STEP 6: SMOTE-ENN ON SELECTED FEATURES
# ============================================
print(f'\n Applying SMOTE-ENN on {len(selected_features)} selected features')

smote_start = datetime.now()
smote_enn = SMOTEENN(random_state=42, n_jobs=-1)
X_train_balanced, y_train_balanced = smote_enn.fit_resample(
    X_train_selected, y_train
)
smote_time = (datetime.now() - smote_start).total_seconds()

print(f' SMOTE-ENN: {smote_time/60:.1f} min')
print(f'  Original: {len(y_train):,} samples')
print(f'  Balanced: {len(y_train_balanced):,} samples')
print(f'  Fraud rate: {y_train_balanced.mean()*100:.2f}%')

# ============================================
# STEP 7: OPTUNA HYPERPARAMETER OPTIMIZATION
# ============================================
print('\n Optuna hyperparameter optimization (30 trials)')

def objective(trial):
    """Optuna objective function for XGBoost"""
    params = {
        'n_estimators': trial.suggest_int('n_estimators', 100, 400, step=100),
        'max_depth': trial.suggest_int('max_depth', 3, 15),
        'learning_rate': trial.suggest_float('learning_rate', 0.01, 0.3, log=True),
        'subsample': trial.suggest_float('subsample', 0.7, 1.0),
        'colsample_bytree': trial.suggest_float('colsample_bytree', 0.7, 1.0),
        'gamma': trial.suggest_float('gamma', 0, 5),
        'reg_alpha': trial.suggest_float('reg_alpha', 0, 10),
        'reg_lambda': trial.suggest_float('reg_lambda', 0, 10),
        'random_state': 42,
        'n_jobs': 4,
        'eval_metric': 'logloss',
        'scale_pos_weight': 1
    }
    
    xgb = XGBClassifier(**params)
    xgb.fit(X_train_balanced, y_train_balanced)
    
    # Validate on subset
    val_size = min(50000, len(X_train_balanced))
    X_val = X_train_balanced.sample(n=val_size, random_state=42)
    y_val = y_train_balanced.loc[X_val.index]
    
    y_val_pred_proba = xgb.predict_proba(X_val)[:, 1]
    
    precisions, recalls, thresholds = precision_recall_curve(y_val, y_val_pred_proba)
    f1_scores = 2 * (precisions[:-1] * recalls[:-1]) / (precisions[:-1] + recalls[:-1] + 1e-10)
    optimal_threshold = thresholds[np.argmax(f1_scores)]
    
    y_val_pred = (y_val_pred_proba >= optimal_threshold).astype(int)
    
    return f1_score(y_val, y_val_pred)

optuna_start = datetime.now()
study = optuna.create_study(direction='maximize', study_name='XGB_Exp3C')
study.optimize(objective, n_trials=30, show_progress_bar=True)
optuna_time = (datetime.now() - optuna_start).total_seconds()

print(f'\nOptuna: {optuna_time/60:.1f} min')
print(f' Best F1 (validation): {study.best_value:.4f}')
print(f'\nBest hyperparameters:')
for param, value in study.best_params.items():
    print(f'  {param}: {value}')

best_params = study.best_params
best_params['random_state'] = 42
best_params['n_jobs'] = 4
best_params['eval_metric'] = 'logloss'
best_params['scale_pos_weight'] = 1

# ============================================
# STEP 8: TRAIN FINAL XGBOOST
# ============================================
print('\n Training final XGBoost with best parameters...')

train_start = datetime.now()
xgb_final = XGBClassifier(**best_params)
xgb_final.fit(X_train_balanced, y_train_balanced)
train_time = (datetime.now() - train_start).total_seconds()

print(f' Training: {train_time:.1f}s')

# ============================================
# STEP 9: 5-FOLD CROSS-VALIDATION
# ============================================
print('\n 5-Fold CV...')

skf = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)

cv_f1 = []
cv_precision = []
cv_recall = []
cv_mcc = []
cv_roc_auc = []

for fold, (train_idx, val_idx) in enumerate(skf.split(X_train_balanced, y_train_balanced), 1):
    print(f'  Fold {fold}/5...', end=' ')
    
    X_fold_train = X_train_balanced.iloc[train_idx]
    y_fold_train = y_train_balanced.iloc[train_idx]
    X_fold_val = X_train_balanced.iloc[val_idx]
    y_fold_val = y_train_balanced.iloc[val_idx]
    
    xgb_fold = XGBClassifier(**best_params)
    xgb_fold.fit(X_fold_train, y_fold_train)
    
    y_val_proba = xgb_fold.predict_proba(X_fold_val)[:, 1]
    
    precisions, recalls, thresholds = precision_recall_curve(y_fold_val, y_val_proba)
    f1_scores = 2 * (precisions[:-1] * recalls[:-1]) / (precisions[:-1] + recalls[:-1] + 1e-10)
    optimal_threshold = thresholds[np.argmax(f1_scores)]
    y_val_pred = (y_val_proba >= optimal_threshold).astype(int)
    
    cv_f1.append(f1_score(y_fold_val, y_val_pred))
    cv_precision.append(precision_score(y_fold_val, y_val_pred, zero_division=0))
    cv_recall.append(recall_score(y_fold_val, y_val_pred))
    cv_mcc.append(matthews_corrcoef(y_fold_val, y_val_pred))
    cv_roc_auc.append(roc_auc_score(y_fold_val, y_val_proba))
    
    print(f'F1={cv_f1[-1]:.4f}')

print(f'\n CV Results:')
print(f'  F1:        {np.mean(cv_f1):.4f} ± {np.std(cv_f1):.4f}')
print(f'  Precision: {np.mean(cv_precision):.4f} ± {np.std(cv_precision):.4f}')
print(f'  Recall:    {np.mean(cv_recall):.4f} ± {np.std(cv_recall):.4f}')
print(f'  MCC:       {np.mean(cv_mcc):.4f} ± {np.std(cv_mcc):.4f}')
print(f'  ROC-AUC:   {np.mean(cv_roc_auc):.4f} ± {np.std(cv_roc_auc):.4f}')

# ============================================
# STEP 10: TEST SET EVALUATION
# ============================================
print('\n[STEP 10/11] Final test set evaluation...')

y_train_pred_proba = xgb_final.predict_proba(X_train_balanced)[:, 1]
y_test_pred_proba = xgb_final.predict_proba(X_test_selected)[:, 1]

precisions, recalls, thresholds = precision_recall_curve(y_test, y_test_pred_proba)
f1_scores = 2 * (precisions[:-1] * recalls[:-1]) / (precisions[:-1] + recalls[:-1] + 1e-10)
optimal_threshold = thresholds[np.argmax(f1_scores)]

print(f' Optimal threshold: {optimal_threshold:.4f}')

y_test_pred = (y_test_pred_proba >= optimal_threshold).astype(int)
y_train_pred = (y_train_pred_proba >= optimal_threshold).astype(int)

train_f1 = f1_score(y_train_balanced, y_train_pred)
train_mcc = matthews_corrcoef(y_train_balanced, y_train_pred)
train_auc = roc_auc_score(y_train_balanced, y_train_pred_proba)

test_f1 = f1_score(y_test, y_test_pred)
test_prec = precision_score(y_test, y_test_pred, zero_division=0)
test_rec = recall_score(y_test, y_test_pred)
test_mcc = matthews_corrcoef(y_test, y_test_pred)
test_auc = roc_auc_score(y_test, y_test_pred_proba)

cm = confusion_matrix(y_test, y_test_pred)
tn, fp, fn, tp = cm.ravel()

cv_test_gap = np.mean(cv_f1) - test_f1

# ============================================
# STEP 11: RESULTS SUMMARY
# ============================================
print('\n' + '='*70)
print('EXPERIMENT 3C: XGBOOST LR-BASED FEATURE SELECTION')
print('='*70)

print(f'\nFeature Selection Strategy:')
print(f'  Method: LR coefficients + domain knowledge')
print(f'  Features: {len(selected_features)} selected from 23')

print(f'\nSelected Features:')
for i, feat in enumerate(selected_features, 1):
    coef = lr_coefs[lr_coefs['feature']==feat]['coefficient'].values[0]
    xgb_imp = xgb_final.feature_importances_[i-1]
    print(f'  {i:2d}. {feat:25s} (LR: {coef:+.4f}, XGB: {xgb_imp:.4f})')

print(f'\nCV (5-Fold):  F1={np.mean(cv_f1):.4f} ± {np.std(cv_f1):.4f}, MCC={np.mean(cv_mcc):.4f} ± {np.std(cv_mcc):.4f}')
print(f'Train:        F1={train_f1:.4f}, MCC={train_mcc:.4f}, AUC={train_auc:.4f}')
print(f'Test:         F1={test_f1:.4f}, Prec={test_prec:.4f}, Rec={test_rec:.4f}')
print(f'              MCC={test_mcc:.4f}, AUC={test_auc:.4f}')

print(f'\nCV-Test Gap:  {cv_test_gap:.4f}')

print(f'\n--- COMPARISON ---')
print(f'EXP 2 (5 feat, baseline):       F1=0.3068, MCC=0.3947')
print(f'EXP 3 (23 feat, XGBoost):       F1=0.4269, MCC=0.4390')
print(f'EXP 3C ({len(selected_features)} feat, XGB+LR):     F1={test_f1:.4f}, MCC={test_mcc:.4f} (gap={cv_test_gap:.2f})')

improvement_vs_exp2 = ((test_f1 - 0.3068) / 0.3068) * 100
improvement_vs_exp3 = ((test_f1 - 0.4269) / 0.4269) * 100

print(f'\nImprovement vs Exp 2:  {improvement_vs_exp2:+.1f}%')
print(f'Improvement vs Exp 3:  {improvement_vs_exp3:+.1f}%')

print('\n' + '='*70)

print(f'\nConfusion Matrix:')
print(f'  TN={tn:,}, FP={fp:,}')
print(f'  FN={fn:,}, TP={tp:,}')
print(f'\nFrauds Caught: {tp}/{tp+fn} ({(tp/(tp+fn))*100:.1f}%)')
print(f'False Alarms: {fp:,}')

# ============================================
# SAVE RESULTS
# ============================================
print('\n[SAVING RESULTS]')

results = {
    'experiment': 'Experiment_3C_XGBoost_LR_Selection',
    'model': 'XGBoost',
    'selection_method': 'Logistic Regression coefficients + domain knowledge',
    'n_features_start': 23,
    'n_features_final': len(selected_features),
    'selected_features': selected_features,
    'best_params': best_params,
    'lr_coefficients': lr_coefs.to_dict('records'),
    
    'cv_f1_mean': float(np.mean(cv_f1)),
    'cv_f1_std': float(np.std(cv_f1)),
    'cv_mcc_mean': float(np.mean(cv_mcc)),
    'cv_test_gap': float(cv_test_gap),
    
    'test_f1': float(test_f1),
    'test_precision': float(test_prec),
    'test_recall': float(test_rec),
    'test_mcc': float(test_mcc),
    'test_roc_auc': float(test_auc),
    
    'test_tp': int(tp),
    'test_tn': int(tn),
    'test_fp': int(fp),
    'test_fn': int(fn),
    
    'exp2_f1': 0.3068,
    'exp3_xgb_f1': 0.4269,
    'improvement_vs_exp2_pct': float(improvement_vs_exp2),
    'improvement_vs_exp3_pct': float(improvement_vs_exp3),
    
    'training_time_seconds': float(train_time),
    'optuna_time_seconds': float(optuna_time),
    'smote_time_seconds': float(smote_time)
}

with open('/Users/henriette/Desktop/Dissertation/Results/exp3c_xgboost_results.json', 'w') as f:
    json.dump(results, f, indent=4)
print(' Results saved: exp3c_xgboost_results.json')

feat_imp = pd.DataFrame({
    'feature': selected_features,
    'lr_coefficient': [lr_coefs[lr_coefs['feature']==f]['coefficient'].values[0] for f in selected_features],
    'xgb_importance': xgb_final.feature_importances_
}).sort_values('xgb_importance', ascending=False)

feat_imp.to_csv('/Users/henriette/Desktop/Dissertation/Results/exp3c_xgboost_feature_importance.csv', index=False)
print(' Feature importance saved: exp3c_xgboost_feature_importance.csv')

print('\n' + '='*70)
print(' EXPERIMENT 3C (XGBOOST) COMPLETE')
print('='*70)
print(f'\nTotal time: {(datetime.now() - smote_start).total_seconds()/60:.1f} min')
print('\nGenerated files:')
print('  1. exp3c_xgboost_results.json')
print('  2. exp3c_xgboost_feature_importance.csv')
print('\nAll saved to: /Users/henriette/Desktop/Dissertation/Results/')