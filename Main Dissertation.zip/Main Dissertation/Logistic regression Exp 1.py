import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import GridSearchCV, cross_val_score
from imblearn.combine import SMOTEENN
from sklearn.metrics import (classification_report, confusion_matrix, f1_score, 
                             precision_score, recall_score, roc_auc_score, roc_curve, auc,
                             matthews_corrcoef, accuracy_score, precision_recall_curve,
                             make_scorer)
import matplotlib.pyplot as plt
import seaborn as sns
from datetime import datetime
import warnings
warnings.filterwarnings('ignore')

# Gini function

def gini(y_true, y_pred, sample=None):
    """Calculate Gini coefficient from ROC-AUC"""
    fpr, tpr, _ = roc_curve(y_true, y_pred)
    gini_score = 100 * (2 * auc(fpr, tpr) - 1)
    if sample:
        print(f'Gini on {sample} = {gini_score:.1f}%')
    return gini_score, fpr, tpr

def plot_gini(y_true_train, y_pred_train, y_true_test, y_pred_test, model_name='Model'):
    """Plot ROC curves for train and test sets"""
    fig = plt.figure(figsize=(10, 7))
    ax = fig.add_subplot(1, 1, 1)

    train_gini, fpr_train, tpr_train = gini(y_true_train, y_pred_train)
    test_gini, fpr_test, tpr_test = gini(y_true_test, y_pred_test)
    
    ax.plot(fpr_test, tpr_test, color='green', linewidth=2.5, 
            label=f'Test (GINI = {test_gini:.1f}%, AUC = {(test_gini/100 + 1)/2:.4f})')
    ax.plot(fpr_train, tpr_train, color='red', linewidth=2.5, 
            label=f'Train (GINI = {train_gini:.1f}%, AUC = {(train_gini/100 + 1)/2:.4f})')
    ax.plot([0, 1], [0, 1], color='navy', lw=2, linestyle='--', label='Random (GINI = 0%)')
    
    ax.set_xlabel('False Positive Rate', fontsize=12)
    ax.set_ylabel('True Positive Rate', fontsize=12)
    ax.set_title(f'ROC Curve - {model_name}\n(Experiment 1: Lokanan Replication)', 
                 fontsize=14, fontweight='bold')
    ax.legend(loc="lower right", frameon=True, fontsize=11)
    ax.grid(alpha=0.3)
    
    plt.tight_layout()
    return fig, train_gini, test_gini

print('='*70)
print("Experiment 1: Logistic Regression - Lokanan's Replication")
print("5-FOLD CV + ROC CURVES + GINI COEFFICIENT")
print('='*70)

#Load Preprocessed Data

print('\n Loading preprocessed data...')
X_train = pd.read_csv('/Users/henriette/Desktop/Dissertation/Data/X_train_exp1.csv')
X_test = pd.read_csv('/Users/henriette/Desktop/Dissertation/Data/X_test_exp1.csv')
y_train = pd.read_csv('/Users/henriette/Desktop/Dissertation/Data/y_train_exp1.csv').squeeze()
y_test = pd.read_csv('/Users/henriette/Desktop/Dissertation/Data/y_test_exp1.csv').squeeze()

print(f' Training set: {X_train.shape[0]:,} samples, {X_train.shape[1]} features')
print(f' Test set: {X_test.shape[0]:,} samples, {X_test.shape[1]} features')
print(f' Training fraud rate: {y_train.mean()*100:.4f}%')
print(f' Test fraud rate: {y_test.mean()*100:.4f}%')

if X_train.shape[1] == 8:
    print('CORRECT: 8 features (matching Lokanan Figure 2)')

# Feature Scaling

print('\n Applying MinMaxScaler...')

scaler = MinMaxScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

X_train_scaled = pd.DataFrame(X_train_scaled, columns=X_train.columns)
X_test_scaled = pd.DataFrame(X_test_scaled, columns=X_test.columns)

print(' Features scaled to range [0, 1]')

# Apply SMOTE-ENN

print('\n Applying SMOTE-ENN...')

smote_start = datetime.now()
smote_enn = SMOTEENN(random_state=42, n_jobs=-1)
X_train_balanced, y_train_balanced = smote_enn.fit_resample(X_train_scaled, y_train)
smote_time = (datetime.now() - smote_start).total_seconds()

print(f' SMOTE-ENN complete in: {smote_time:.1f} seconds ({smote_time/60:.1f} minutes)')
print(f'  After SMOTE: {len(y_train_balanced):,} samples ({y_train_balanced.mean()*100:.2f}% fraud)')


# HYPERPARAMETER TUNING (5-FOLD CV)

print('\n Hyperparameter tuning with 5-Fold Cross-Validation...')
print('Testing parameters from Lokanan (2023) Appendix 1')

param_grid = {
    'C': [0.01, 1.0, 10.0],
    'penalty': ['l1', 'l2'],
    'solver': ['liblinear'],
    'max_iter': [1000],
    'random_state': [42]
}

base_model = LogisticRegression()

grid_search = GridSearchCV(
    base_model,
    param_grid,
    cv=5,  
    scoring='f1',
    n_jobs=-1,
    verbose=0
)

tune_start = datetime.now()
grid_search.fit(X_train_balanced, y_train_balanced)
tune_time = (datetime.now() - tune_start).total_seconds()

print(f'\n Grid search complete in {tune_time:.1f} seconds ({tune_time/60:.1f} minutes)')
print(f'\nBest parameters found:')
print(f'  C: {grid_search.best_params_["C"]}')
print(f'  Penalty: {grid_search.best_params_["penalty"]}')
print(f'  Best 5-Fold CV F1 score: {grid_search.best_score_:.4f}')
print(f'  Lokanan\'s reported F1: 0.85')
print(f'  Difference: {abs(grid_search.best_score_ - 0.85):.4f}')

if 0.80 <= grid_search.best_score_ <= 0.90:
    print(f'CV F1 MATCHES LOKANAN\'S RANGE!')

# Calculate CV MCC
print('\nCalculating 5-Fold CV MCC...')
mcc_scorer = make_scorer(matthews_corrcoef)
cv_mcc_scores = cross_val_score(grid_search.best_estimator_, 
                                 X_train_balanced, y_train_balanced,
                                 cv=5, scoring=mcc_scorer, n_jobs=-1)
cv_mcc = cv_mcc_scores.mean()
cv_mcc_std = cv_mcc_scores.std()

print(f' CV MCC: {cv_mcc:.4f} (±{cv_mcc_std:.4f})')
print(f'  Lokanan\'s reported MCC: 0.68')
print(f'  Difference: {abs(cv_mcc - 0.68):.4f}')

lr_model = grid_search.best_estimator_

# Making predictions on train and test sets

# Train predictions (for ROC curve comparison)
y_train_pred_proba = lr_model.predict_proba(X_train_balanced)[:, 1]

# Test predictions
y_test_pred_proba = lr_model.predict_proba(X_test_scaled)[:, 1]

print('Predictions complete')


#  Finding F1-optimal threshold on test set (F1-Maximizing)

precisions, recalls, thresholds = precision_recall_curve(y_test, y_test_pred_proba)
f1_scores = 2 * (precisions[:-1] * recalls[:-1]) / (precisions[:-1] + recalls[:-1] + 1e-10)

optimal_idx = np.argmax(f1_scores)
optimal_threshold = thresholds[optimal_idx]
optimal_precision = precisions[optimal_idx]
optimal_recall = recalls[optimal_idx]
optimal_f1 = f1_scores[optimal_idx]

print(f'  F1-Optimal threshold: {optimal_threshold:.4f}')
print(f'  Expected Performance:')
print(f'    Precision: {optimal_precision:.4f}')
print(f'    Recall: {optimal_recall:.4f}')
print(f'    F1: {optimal_f1:.4f}')

# Apply optimal threshold
y_test_pred_optimal = (y_test_pred_proba >= optimal_threshold).astype(int)
y_train_pred_optimal = (y_train_pred_proba >= optimal_threshold).astype(int)

print(f'\nTest set predictions:')
print(f'  Predicted {y_test_pred_optimal.sum():,} frauds out of {len(y_test):,}')
print(f'  Prediction rate: {y_test_pred_optimal.mean()*100:.4f}%')


#Calculating the Metrics

# Test metrics
test_accuracy = accuracy_score(y_test, y_test_pred_optimal)
test_f1 = f1_score(y_test, y_test_pred_optimal)
test_precision = precision_score(y_test, y_test_pred_optimal)
test_recall = recall_score(y_test, y_test_pred_optimal)
test_roc_auc = roc_auc_score(y_test, y_test_pred_proba)
test_mcc = matthews_corrcoef(y_test, y_test_pred_optimal)

# Train metrics (for comparison)
train_accuracy = accuracy_score(y_train_balanced, y_train_pred_optimal)
train_f1 = f1_score(y_train_balanced, y_train_pred_optimal)
train_mcc = matthews_corrcoef(y_train_balanced, y_train_pred_optimal)
train_roc_auc = roc_auc_score(y_train_balanced, y_train_pred_proba)

print('\n' + '='*70)
print('LOGISTIC REGRESSION RESULTS - EXPERIMENT 1')
print('='*70)

print(f'\nCROSS-VALIDATION (5-Fold on SMOTE-Balanced Training):')
print(f'  CV F1:  {grid_search.best_score_:.4f} (Lokanan: 0.82)')
print(f'  CV MCC: {cv_mcc:.4f} (Lokanan: 0.66)')

print(f'\nTRAINING SET (SMOTE-Balanced, threshold={optimal_threshold:.4f}):')
print(f'  Train Accuracy: {train_accuracy:.4f} (Lokanan: 0.82)')
print(f'  Train F1:       {train_f1:.4f}')
print(f'  Train MCC:      {train_mcc:.4f} (Lokanan: 0.66)')
print(f'  Train ROC-AUC:  {train_roc_auc:.4f}')

print(f'\nTEST SET (Imbalanced, threshold={optimal_threshold:.4f}):')
print(f'{"Metric":<15} {"Your Result":<12} {"Lokanan":<12} {"Δ"}')
print('-'*50)
print(f'{"Accuracy":<15} {test_accuracy:<12.4f} {"0.83":<12} {abs(test_accuracy-0.83):.4f}')
print(f'{"Precision":<15} {test_precision:<12.4f} {"0.76":<12} {abs(test_precision-0.76):.4f}')
print(f'{"Recall":<15} {test_recall:<12.4f} {"0.96":<12} {abs(test_recall-0.96):.4f}')
print(f'{"F1":<15} {test_f1:<12.4f} {"0.85":<12} {abs(test_f1-0.85):.4f}')
print(f'{"MCC":<15} {test_mcc:<12.4f} {"0.68":<12} {abs(test_mcc-0.68):.4f}')
print(f'{"ROC-AUC":<15} {test_roc_auc:<12.4f} {"0.93":<12} {abs(test_roc_auc-0.93):.4f}')
print('='*70)

if 0.80 <= grid_search.best_score_ <= 0.90:
    print('\n CV F1 matches Lokanan\'s reported performance!')
    
print('\n' + classification_report(y_test, y_test_pred_optimal, 
                                   target_names=['Legitimate', 'Fraud'], 
                                   digits=4))


#  Generating ROC curve with Gini coefficient

fig_roc, train_gini, test_gini = plot_gini(
    y_train_balanced, y_train_pred_proba,
    y_test, y_test_pred_proba,
    model_name='Logistic Regression'
)

plt.savefig('/Users/henriette/Desktop/Dissertation/Results/exp1_lr_roc_curve.png', 
            dpi=300, bbox_inches='tight')
print(f' ROC curve saved')
print(f'  Train Gini: {train_gini:.1f}% (ROC-AUC: {train_roc_auc:.4f})')
print(f'  Test Gini:  {test_gini:.1f}% (ROC-AUC: {test_roc_auc:.4f})')
plt.show()


# Generating confusion matrix

cm = confusion_matrix(y_test, y_test_pred_optimal)
cm_percent = cm.astype(float) / cm.sum(axis=1)[:, np.newaxis] * 100

print(f'\nConfusion Matrix:')
print(f'  TN: {cm[0,0]:,} ({cm_percent[0,0]:.2f}%)  FP: {cm[0,1]:,} ({cm_percent[0,1]:.2f}%)')
print(f'  FN: {cm[1,0]:,} ({cm_percent[1,0]:.2f}%)  TP: {cm[1,1]:,} ({cm_percent[1,1]:.2f}%)')

fig, ax = plt.subplots(figsize=(10, 8))
sns.heatmap(cm, annot=True, fmt='d', cmap='Blues',
            xticklabels=['Legitimate', 'Fraud'],
            yticklabels=['Legitimate', 'Fraud'])

for i in range(cm.shape[0]):
    for j in range(cm.shape[1]):
        ax.text(j+0.5, i+0.7, f'({cm_percent[i,j]:.2f}%)', 
                ha='center', va='center', fontsize=10, color='gray')

plt.title("Confusion Matrix - Logistic Regression\n(Experiment 1: 5-Fold CV)", 
          fontsize=14, fontweight='bold')
plt.ylabel('Actual', fontsize=12)
plt.xlabel('Predicted', fontsize=12)
plt.tight_layout()
plt.savefig('/Users/henriette/Desktop/Dissertation/Results/exp1_lr_confusion_matrix.png', 
            dpi=300, bbox_inches='tight')
print(' Confusion matrix saved')
plt.show()

# ============================================
# ADDITIONAL VISUALIZATIONS (Confusion Matrix + Feature Importance)
# ============================================

print('\n[BONUS] Creating additional visualizations...')

# Get feature coefficients (importance for logistic regression)
feature_importance = pd.DataFrame({
    'feature': X_train.columns,
    'coefficient': np.abs(lr_model.coef_[0])  # Absolute value of coefficients
}).sort_values('coefficient', ascending=False)

# Normalize to get "importance" as percentage
feature_importance['importance'] = (feature_importance['coefficient'] / 
                                   feature_importance['coefficient'].sum())

print('\nTop 10 Feature Coefficients (Logistic Regression):')
print(feature_importance.head(10).to_string(index=False))

# Create side-by-side plot
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(16, 6))

# Confusion Matrix
cm = confusion_matrix(y_test, y_test_pred_optimal)
cm_percent = cm.astype(float) / cm.sum(axis=1)[:, np.newaxis] * 100

sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', ax=ax1,
            xticklabels=['Legitimate', 'Fraud'],
            yticklabels=['Legitimate', 'Fraud'])
for i in range(cm.shape[0]):
    for j in range(cm.shape[1]):
        ax1.text(j+0.5, i+0.7, f'({cm_percent[i,j]:.2f}%)', 
                ha='center', va='center', fontsize=10, color='gray')
ax1.set_title("Confusion Matrix - Logistic Regression\n(Experiment 1: 5-Fold CV)", 
             fontsize=14, fontweight='bold')
ax1.set_ylabel('Actual', fontsize=12)
ax1.set_xlabel('Predicted', fontsize=12)

# Feature Importance (Coefficients)
feature_importance.head(8).plot(kind='barh', x='feature', y='importance', ax=ax2, 
                                legend=False, color='blue')
ax2.set_title('Top 8 Feature Importances\n(Absolute Coefficients)', 
             fontsize=14, fontweight='bold')
ax2.set_xlabel('Importance', fontsize=12)
ax2.invert_yaxis()

plt.tight_layout()
plt.savefig('/Users/henriette/Desktop/Dissertation/Results/exp1_lr_confusion_feature_importance.png', 
            dpi=300, bbox_inches='tight')
print('✓ Confusion matrix and feature importance saved')
plt.show()

print('\n' + '='*70)
print('LOGISTIC REGRESSION COMPLETE (WITH ALL VISUALIZATIONS)')
print('='*70)


# Save predictions
results_df = pd.DataFrame({
    'y_true': y_test.values,
    'y_pred': y_test_pred_optimal,
    'y_pred_proba': y_test_pred_proba
})
results_df.to_csv('/Users/henriette/Desktop/Dissertation/Results/exp1_lr_predictions.csv', index=False)

# Save metrics summary
metrics_summary = {
    'Model': 'Logistic Regression',
    'Experiment': 'Experiment 1 (5-Fold CV)',
    'Features_Used': X_train.shape[1],
    'Best_C': grid_search.best_params_['C'],
    'Best_Penalty': grid_search.best_params_['penalty'],
    'CV_F1_Score': grid_search.best_score_,
    'CV_MCC_Score': cv_mcc,
    'Train_Accuracy': train_accuracy,
    'Train_F1': train_f1,
    'Train_MCC': train_mcc,
    'Train_ROC_AUC': train_roc_auc,
    'Train_Gini': train_gini,
    'Optimal_Threshold': optimal_threshold,
    'Test_Accuracy': test_accuracy,
    'Test_Precision': test_precision,
    'Test_Recall': test_recall,
    'Test_F1_Score': test_f1,
    'Test_MCC': test_mcc,
    'Test_ROC_AUC': test_roc_auc,
    'Test_Gini': test_gini,
    'Tuning_Time_Seconds': tune_time,
    'SMOTE_Time_Seconds': smote_time,
    'Date': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
}

pd.DataFrame([metrics_summary]).to_csv(
    '/Users/henriette/Desktop/Dissertation/Results/exp1_lr_metrics.csv', 
    index=False
)

print('\n Results saved')
print('\n' + '='*70)
print('LOGISTIC REGRESSION COMPLETE')
print('='*70)

