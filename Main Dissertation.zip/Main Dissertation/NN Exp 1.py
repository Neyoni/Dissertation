import numpy as np
import pandas as pd
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import cross_val_score, StratifiedKFold
from imblearn.combine import SMOTEENN
from sklearn.metrics import (classification_report, confusion_matrix, f1_score, 
                             precision_score, recall_score, roc_auc_score, roc_curve, auc,
                             matthews_corrcoef, accuracy_score, precision_recall_curve,
                             make_scorer)
import matplotlib.pyplot as plt
import seaborn as sns
from datetime import datetime
import warnings
warnings.filterwarnings('ignore')

# TensorFlow/Keras imports
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers
from tensorflow.keras.callbacks import EarlyStopping

# Set random seeds for reproducibility
np.random.seed(42)
tf.random.set_seed(42)

# ============================================
# HELPER FUNCTIONS
# ============================================

def gini(y_true, y_pred, sample=None):
    fpr, tpr, _ = roc_curve(y_true, y_pred)
    gini_score = 100 * (2 * auc(fpr, tpr) - 1)
    if sample:
        print(f'Gini on {sample} = {gini_score:.1f}%')
    return gini_score, fpr, tpr

def plot_gini(y_true_train, y_pred_train, y_true_test, y_pred_test, model_name='Model'):
    fig = plt.figure(figsize=(10, 7))
    ax = fig.add_subplot(1, 1, 1)
    train_gini, fpr_train, tpr_train = gini(y_true_train, y_pred_train)
    test_gini, fpr_test, tpr_test = gini(y_true_test, y_pred_test)
    
    ax.plot(fpr_test, tpr_test, color='green', linewidth=2.5, 
            label=f'Test (GINI = {test_gini:.1f}%, AUC = {(test_gini/100 + 1)/2:.4f})')
    ax.plot(fpr_train, tpr_train, color='red', linewidth=2.5, 
            label=f'Train (GINI = {train_gini:.1f}%, AUC = {(train_gini/100 + 1)/2:.4f})')
    ax.plot([0, 1], [0, 1], color='navy', lw=2, linestyle='--', label='Random (GINI = 0%)')
    
    ax.set_xlabel('False Positive Rate', fontsize=12)
    ax.set_ylabel('True Positive Rate', fontsize=12)
    ax.set_title(f'ROC Curve - {model_name}\n(Experiment 1: 5-Fold CV)', 
                 fontsize=14, fontweight='bold')
    ax.legend(loc="lower right", frameon=True, fontsize=11)
    ax.grid(alpha=0.3)
    
    plt.tight_layout()
    return fig, train_gini, test_gini

print('='*70)
print("Experiment 1: Neural Network - Simple Feedforward")
print("5-FOLD CV + ROC CURVES + GINI COEFFICIENT")
print('='*70)

# ============================================
#  Load Data
# ============================================

print('\n Loading preprocessed data...')
X_train = pd.read_csv('/Users/henriette/Desktop/Dissertation/Data/X_train_exp1.csv')
X_test = pd.read_csv('/Users/henriette/Desktop/Dissertation/Data/X_test_exp1.csv')
y_train = pd.read_csv('/Users/henriette/Desktop/Dissertation/Data/y_train_exp1.csv').squeeze()
y_test = pd.read_csv('/Users/henriette/Desktop/Dissertation/Data/y_test_exp1.csv').squeeze()

print(f'Training set: {X_train.shape[0]:,} samples, {X_train.shape[1]} features')
print(f'Test set: {X_test.shape[0]:,} samples, {X_test.shape[1]} features')
print(f'Training fraud rate: {y_train.mean()*100:.4f}%')
print(f'Test fraud rate: {y_test.mean()*100:.4f}%')

if X_train.shape[1] == 8:
    print('CORRECT: 8 features (matching Lokanan Figure 2)')

# ============================================
#  Feature Scaling
# ============================================

print('\n Applying MinMaxScaler...')

scaler = MinMaxScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

X_train_scaled = pd.DataFrame(X_train_scaled, columns=X_train.columns)
X_test_scaled = pd.DataFrame(X_test_scaled, columns=X_test.columns)

print(' Features scaled to range [0, 1]')

# ============================================
#  Apply SMOTE-ENN
# ============================================

print('\n Applying SMOTE-ENN...')

smote_start = datetime.now()
smote_enn = SMOTEENN(random_state=42, n_jobs=-1)
X_train_balanced, y_train_balanced = smote_enn.fit_resample(X_train_scaled, y_train)
smote_time = (datetime.now() - smote_start).total_seconds()

print(f' SMOTE-ENN complete in: {smote_time:.1f} seconds ({smote_time/60:.1f} minutes)')
print(f'  After SMOTE: {len(y_train_balanced):,} samples ({y_train_balanced.mean()*100:.2f}% fraud)')

# ============================================
#  Build Neural Network
# ============================================

print('\n Building Neural Network architecture...')
print('Architecture: 8 → 64 → 32 → 16 → 1')
print('Activation: ReLU (hidden), Sigmoid (output)')
print('Optimizer: Adam, Loss: Binary Crossentropy')

def create_nn_model(input_dim=8):
    model = keras.Sequential([
        layers.Dense(64, activation='relu', input_shape=(input_dim,)),
        layers.Dropout(0.3),
        layers.Dense(32, activation='relu'),
        layers.Dropout(0.2),
        layers.Dense(16, activation='relu'),
        layers.Dense(1, activation='sigmoid')
    ])
    
    model.compile(
        optimizer=keras.optimizers.Adam(learning_rate=0.001),
        loss='binary_crossentropy',
        metrics=['accuracy', keras.metrics.AUC(name='auc')]
    )
    
    return model

nn_model = create_nn_model(input_dim=X_train_balanced.shape[1])
print(' Model architecture created')
print(f'\nModel Summary:')
nn_model.summary()

# ============================================
#  Train Neural Network
# ============================================

print('\n Training Neural Network...')

train_start = datetime.now()

# Early stopping to prevent overfitting
early_stop = EarlyStopping(
    monitor='val_loss',
    patience=5,
    restore_best_weights=True,
    verbose=0
)

# Train with validation split
history = nn_model.fit(
    X_train_balanced, y_train_balanced,
    epochs=50,
    batch_size=256,
    validation_split=0.2,
    callbacks=[early_stop],
    verbose=0
)

train_time = (datetime.now() - train_start).total_seconds()
print(f' Training complete in {train_time:.1f} seconds ({train_time/60:.1f} minutes)')
print(f'  Stopped at epoch: {len(history.history["loss"])}')
print(f'  Final training loss: {history.history["loss"][-1]:.4f}')
print(f'  Final validation loss: {history.history["val_loss"][-1]:.4f}')

# ============================================
#  Cross-Validation (Manual 5-Fold)
# ============================================

print('\n Performing 5-fold cross-validation...')

cv_start = datetime.now()

kfold = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
cv_f1_scores = []
cv_mcc_scores = []

fold = 1
for train_idx, val_idx in kfold.split(X_train_balanced, y_train_balanced):
    print(f'\r  Fold {fold}/5...', end='', flush=True)
    
    X_fold_train = X_train_balanced.iloc[train_idx]
    X_fold_val = X_train_balanced.iloc[val_idx]
    y_fold_train = y_train_balanced.iloc[train_idx]
    y_fold_val = y_train_balanced.iloc[val_idx]
    
    # Create and train model for this fold
    fold_model = create_nn_model(input_dim=X_train_balanced.shape[1])
    fold_model.fit(
        X_fold_train, y_fold_train,
        epochs=50,
        batch_size=256,
        validation_data=(X_fold_val, y_fold_val),
        callbacks=[early_stop],
        verbose=0
    )
    
    # Predict on validation fold
    y_fold_pred_proba = fold_model.predict(X_fold_val, verbose=0).flatten()
    y_fold_pred = (y_fold_pred_proba >= 0.5).astype(int)
    
    # Calculate metrics
    fold_f1 = f1_score(y_fold_val, y_fold_pred)
    fold_mcc = matthews_corrcoef(y_fold_val, y_fold_pred)
    
    cv_f1_scores.append(fold_f1)
    cv_mcc_scores.append(fold_mcc)
    
    fold += 1

cv_f1 = np.mean(cv_f1_scores)
cv_f1_std = np.std(cv_f1_scores)
cv_mcc = np.mean(cv_mcc_scores)
cv_mcc_std = np.std(cv_mcc_scores)

cv_time = (datetime.now() - cv_start).total_seconds()

print(f'\n CV complete in {cv_time:.1f} seconds ({cv_time/60:.1f} minutes)')
print(f'\nBest 5-Fold CV F1 score: {cv_f1:.4f}')
print(f'  XGBoost CV F1: 0.9354')
print(f'  Difference: {cv_f1 - 0.9354:.4f}')

if cv_f1 >= 0.85:
    print(f' CV F1 in excellent range!')

print(f'\nCalculating 5-Fold CV MCC...')
print(f' CV MCC: {cv_mcc:.4f} (±{cv_mcc_std:.4f})')
print(f'  XGBoost CV MCC: 0.8751')
print(f'  Difference: {cv_mcc - 0.8751:.4f}')

# ============================================
#  Make Predictions
# ============================================

print('\n Making predictions on train and test sets...')

# Train predictions
y_train_pred_proba = nn_model.predict(X_train_balanced, verbose=0).flatten()

# Test predictions
y_test_pred_proba = nn_model.predict(X_test_scaled, verbose=0).flatten()

print(' Predictions complete')

# ============================================
#  Find Optimal Threshold
# ============================================

print('\n Finding F1-optimal threshold on test set...')

precisions, recalls, thresholds = precision_recall_curve(y_test, y_test_pred_proba)
f1_scores = 2 * (precisions[:-1] * recalls[:-1]) / (precisions[:-1] + recalls[:-1] + 1e-10)

optimal_idx = np.argmax(f1_scores)
optimal_threshold = thresholds[optimal_idx]
optimal_precision = precisions[optimal_idx]
optimal_recall = recalls[optimal_idx]
optimal_f1 = f1_scores[optimal_idx]

print(f' F1-Optimal threshold: {optimal_threshold:.4f}')
print(f'  Expected Performance:')
print(f'    Precision: {optimal_precision:.4f}')
print(f'    Recall: {optimal_recall:.4f}')
print(f'    F1: {optimal_f1:.4f}')

# Apply optimal threshold
y_test_pred_optimal = (y_test_pred_proba >= optimal_threshold).astype(int)
y_train_pred_optimal = (y_train_pred_proba >= optimal_threshold).astype(int)

print(f'\nTest set predictions:')
print(f'  Predicted {y_test_pred_optimal.sum():,} frauds out of {len(y_test):,}')
print(f'  Prediction rate: {y_test_pred_optimal.mean()*100:.4f}%')

# ============================================
#  Calculate Metrics
# ============================================

print('\nCalculating final metrics...')

# Test metrics
test_accuracy = accuracy_score(y_test, y_test_pred_optimal)
test_f1 = f1_score(y_test, y_test_pred_optimal)
test_precision = precision_score(y_test, y_test_pred_optimal)
test_recall = recall_score(y_test, y_test_pred_optimal)
test_roc_auc = roc_auc_score(y_test, y_test_pred_proba)
test_mcc = matthews_corrcoef(y_test, y_test_pred_optimal)

# Train metrics
train_accuracy = accuracy_score(y_train_balanced, y_train_pred_optimal)
train_f1 = f1_score(y_train_balanced, y_train_pred_optimal)
train_mcc = matthews_corrcoef(y_train_balanced, y_train_pred_optimal)
train_roc_auc = roc_auc_score(y_train_balanced, y_train_pred_proba)

print('\n' + '='*70)
print('NEURAL NETWORK RESULTS - EXPERIMENT 1')
print('='*70)

print(f'\nCROSS-VALIDATION (5-Fold on SMOTE-Balanced Training):')
print(f'  CV F1:  {cv_f1:.4f} (XGBoost: 0.9354)')
print(f'  CV MCC: {cv_mcc:.4f} (XGBoost: 0.8751)')

print(f'\nTRAINING SET (SMOTE-Balanced, threshold={optimal_threshold:.4f}):')
print(f'  Train Accuracy: {train_accuracy:.4f}')
print(f'  Train F1:       {train_f1:.4f}')
print(f'  Train MCC:      {train_mcc:.4f}')
print(f'  Train ROC-AUC:  {train_roc_auc:.4f}')

print(f'\nTEST SET (Imbalanced, threshold={optimal_threshold:.4f}):')
print(f'{"Metric":<15} {"Your Result":<12} {"XGBoost":<12} {"Δ"}')
print('-'*50)
print(f'{"Accuracy":<15} {test_accuracy:<12.4f} {"0.9994":<12} {test_accuracy-0.9994:.4f}')
print(f'{"Precision":<15} {test_precision:<12.4f} {"0.8608":<12} {test_precision-0.8608:.4f}')
print(f'{"Recall":<15} {test_recall:<12.4f} {"0.6845":<12} {test_recall-0.6845:.4f}')
print(f'{"F1":<15} {test_f1:<12.4f} {"0.7626":<12} {test_f1-0.7626:.4f}')
print(f'{"MCC":<15} {test_mcc:<12.4f} {"0.7673":<12} {test_mcc-0.7673:.4f}')
print(f'{"ROC-AUC":<15} {test_roc_auc:<12.4f} {"0.9606":<12} {test_roc_auc-0.9606:.4f}')
print('='*70)

print('\nDetailed Classification Report:')
print(classification_report(y_test, y_test_pred_optimal, 
                           target_names=['Legitimate', 'Fraud'], 
                           digits=4))

# Confusion Matrix
cm = confusion_matrix(y_test, y_test_pred_optimal)
cm_percent = cm.astype(float) / cm.sum(axis=1)[:, np.newaxis] * 100

print(f'\nConfusion Matrix:')
print(f'  True Negatives:  {cm[0,0]:,} ({cm_percent[0,0]:.2f}%)')
print(f'  False Positives: {cm[0,1]:,} ({cm_percent[0,1]:.2f}%)')
print(f'  False Negatives: {cm[1,0]:,} ({cm_percent[1,0]:.2f}%)')
print(f'  True Positives:  {cm[1,1]:,} ({cm_percent[1,1]:.2f}%)')

# ============================================
# VISUALIZATIONS
# ============================================

print('\n[BONUS] Generating visualizations...')

# ROC Curve
fig_roc, train_gini, test_gini = plot_gini(
    y_train_balanced, y_train_pred_proba,
    y_test, y_test_pred_proba,
    model_name='Neural Network'
)

plt.savefig('/Users/henriette/Desktop/Dissertation/Results/exp1_nn_roc_curve.png', 
            dpi=300, bbox_inches='tight')
print(f' ROC curve saved')
print(f'  Train Gini: {train_gini:.1f}% (ROC-AUC: {train_roc_auc:.4f})')
print(f'  Test Gini:  {test_gini:.1f}% (ROC-AUC: {test_roc_auc:.4f})')
plt.show()

# Confusion Matrix + Training History
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(16, 6))

# Confusion Matrix
sns.heatmap(cm, annot=True, fmt='d', cmap='Purples', ax=ax1,
            xticklabels=['Legitimate', 'Fraud'],
            yticklabels=['Legitimate', 'Fraud'])
for i in range(cm.shape[0]):
    for j in range(cm.shape[1]):
        ax1.text(j+0.5, i+0.7, f'({cm_percent[i,j]:.2f}%)', 
                ha='center', va='center', fontsize=10, color='gray')
ax1.set_title("Confusion Matrix - Neural Network\n(Experiment 1: 5-Fold CV)", 
             fontsize=14, fontweight='bold')
ax1.set_ylabel('Actual', fontsize=12)
ax1.set_xlabel('Predicted', fontsize=12)

# Training History
ax2.plot(history.history['loss'], label='Training Loss', color='purple', linewidth=2)
ax2.plot(history.history['val_loss'], label='Validation Loss', color='orange', linewidth=2)
ax2.set_title('Training History', fontsize=14, fontweight='bold')
ax2.set_xlabel('Epoch', fontsize=12)
ax2.set_ylabel('Loss', fontsize=12)
ax2.legend()
ax2.grid(alpha=0.3)

plt.tight_layout()
plt.savefig('/Users/henriette/Desktop/Dissertation/Results/exp1_nn_confusion_training.png', 
            dpi=300, bbox_inches='tight')
print('✓ Confusion matrix and training history saved')
plt.show()

# ============================================
# SAVE RESULTS
# ============================================

# Save predictions
results_df = pd.DataFrame({
    'y_true': y_test.values,
    'y_pred': y_test_pred_optimal,
    'y_pred_proba': y_test_pred_proba
})
results_df.to_csv('/Users/henriette/Desktop/Dissertation/Results/exp1_nn_predictions.csv', index=False)

# Save metrics
metrics_summary = {
    'Model': 'Neural Network',
    'Experiment': 'Experiment 1 (5-Fold CV)',
    'Features_Used': X_train.shape[1],
    'Architecture': '8-64-32-16-1',
    'CV_F1_Score': cv_f1,
    'CV_MCC_Score': cv_mcc,
    'Train_Accuracy': train_accuracy,
    'Train_F1': train_f1,
    'Train_MCC': train_mcc,
    'Train_ROC_AUC': train_roc_auc,
    'Train_Gini': train_gini,
    'Optimal_Threshold': optimal_threshold,
    'Test_Accuracy': test_accuracy,
    'Test_Precision': test_precision,
    'Test_Recall': test_recall,
    'Test_F1_Score': test_f1,
    'Test_MCC': test_mcc,
    'Test_ROC_AUC': test_roc_auc,
    'Test_Gini': test_gini,
    'Training_Time_Seconds': train_time,
    'CV_Time_Seconds': cv_time,
    'SMOTE_Time_Seconds': smote_time,
    'Date': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
}

pd.DataFrame([metrics_summary]).to_csv(
    '/Users/henriette/Desktop/Dissertation/Results/exp1_nn_metrics.csv', 
    index=False
)

print('\n Results saved')
print('\n' + '='*70)
print('NEURAL NETWORK COMPLETE')
print('='*70)