import numpy as np
import pandas as pd
from xgboost import XGBClassifier
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import cross_val_score
from imblearn.combine import SMOTEENN
from sklearn.metrics import (classification_report, confusion_matrix, f1_score, 
                             precision_score, recall_score, roc_auc_score, roc_curve, auc,
                             matthews_corrcoef, accuracy_score, precision_recall_curve,
                             make_scorer)
import matplotlib.pyplot as plt
import seaborn as sns
from datetime import datetime
import warnings
warnings.filterwarnings('ignore')

def gini(y_true, y_pred, sample=None):
    fpr, tpr, _ = roc_curve(y_true, y_pred)
    gini_score = 100 * (2 * auc(fpr, tpr) - 1)
    if sample:
        print(f'Gini on {sample} = {gini_score:.1f}%')
    return gini_score, fpr, tpr

def plot_gini(y_true_train, y_pred_train, y_true_test, y_pred_test, model_name='Model'):
    fig = plt.figure(figsize=(10, 7))
    ax = fig.add_subplot(1, 1, 1)
    train_gini, fpr_train, tpr_train = gini(y_true_train, y_pred_train)
    test_gini, fpr_test, tpr_test = gini(y_true_test, y_pred_test)
    
    ax.plot(fpr_test, tpr_test, color='green', linewidth=2.5, 
            label=f'Test (GINI = {test_gini:.1f}%, AUC = {(test_gini/100 + 1)/2:.4f})')
    ax.plot(fpr_train, tpr_train, color='red', linewidth=2.5, 
            label=f'Train (GINI = {train_gini:.1f}%, AUC = {(train_gini/100 + 1)/2:.4f})')
    ax.plot([0, 1], [0, 1], color='navy', lw=2, linestyle='--', label='Random (GINI = 0%)')
    
    ax.set_xlabel('False Positive Rate', fontsize=12)
    ax.set_ylabel('True Positive Rate', fontsize=12)
    ax.set_title(f'ROC Curve - {model_name}\n(Experiment 2: Production Features Only)', 
                 fontsize=14, fontweight='bold')
    ax.legend(loc="lower right", frameon=True, fontsize=11)
    ax.grid(alpha=0.3)
    
    plt.tight_layout()
    return fig, train_gini, test_gini

print('='*70)
print("Experiment 2: XGBoost - PRODUCTION FEATURES ONLY (4 Features)")
print("NO TEMPORAL LEAKAGE - Real-Time Deployment Simulation")
print('='*70)

#  Load Data
print('\n[1/9] Loading preprocessed data...')
X_train_full = pd.read_csv('/Users/henriette/Desktop/Dissertation/Data/X_train_exp1.csv')
X_test_full = pd.read_csv('/Users/henriette/Desktop/Dissertation/Data/X_test_exp1.csv')
y_train = pd.read_csv('/Users/henriette/Desktop/Dissertation/Data/y_train_exp1.csv').squeeze()
y_test = pd.read_csv('/Users/henriette/Desktop/Dissertation/Data/y_test_exp1.csv').squeeze()

print(f'✓ Original Training set: {X_train_full.shape[0]:,} samples, {X_train_full.shape[1]} features')

# SELECT ONLY PRODUCTION FEATURES
production_features = ['amount', 'type_TRANSFER', 'type_PAYMENT', 'type_CASH_OUT','type_CASH_IN']
X_train = X_train_full[production_features].copy()
X_test = X_test_full[production_features].copy()

print(f'\n PRODUCTION FEATURES SELECTED: {len(production_features)} features')
print(f'   Features: {production_features}')
print(f'\n REMOVED (Temporal Leakage):')
print(f'   - oldbalanceDest (recipient balance - might be different bank)')
print(f'   - newbalanceDest (post-transaction - doesn\'t exist yet)')
print(f'   - oldbalanceOrg (will test in Exp 3)')
print(f'   - newbalanceOrg (post-transaction - doesn\'t exist yet)')

print(f'\nTraining set: {X_train.shape[0]:,} samples, {X_train.shape[1]} features')
print(f' Test set: {X_test.shape[0]:,} samples, {X_test.shape[1]} features')

#  Scale
print('\n Applying MinMaxScaler...')
scaler = MinMaxScaler()
X_train_scaled = pd.DataFrame(scaler.fit_transform(X_train), columns=X_train.columns)
X_test_scaled = pd.DataFrame(scaler.transform(X_test), columns=X_test.columns)
print(' Scaled')

#  SMOTE
print('\n Applying SMOTE-ENN...')
smote_start = datetime.now()
smote_enn = SMOTEENN(random_state=42, n_jobs=-1)
X_train_balanced, y_train_balanced = smote_enn.fit_resample(X_train_scaled, y_train)
smote_time = (datetime.now() - smote_start).total_seconds()
print(f' SMOTE: {smote_time:.1f}s ({len(y_train_balanced):,} samples)')

#  Train
print('\n Training XGBoost (n=100, depth=5, lr=0.1)...')
train_start = datetime.now()
xgb_model = XGBClassifier(
    n_estimators=100, max_depth=5, learning_rate=0.1,
    subsample=0.8, colsample_bytree=0.8,
    random_state=42, n_jobs=4,
    eval_metric='logloss', use_label_encoder=False
)
xgb_model.fit(X_train_balanced, y_train_balanced)
train_time = (datetime.now() - train_start).total_seconds()
print(f' Training: {train_time:.1f}s')

#  CV
print('\n 5-Fold CV...')
cv_start = datetime.now()
cv_f1_scores = cross_val_score(xgb_model, X_train_balanced, y_train_balanced, 
                               cv=5, scoring='f1', n_jobs=4, verbose=0)
cv_f1 = cv_f1_scores.mean()
cv_f1_std = cv_f1_scores.std()

mcc_scorer = make_scorer(matthews_corrcoef)
cv_mcc_scores = cross_val_score(xgb_model, X_train_balanced, y_train_balanced,
                                cv=5, scoring=mcc_scorer, n_jobs=4, verbose=0)
cv_mcc = cv_mcc_scores.mean()
cv_time = (datetime.now() - cv_start).total_seconds()

print(f' CV: {cv_time:.1f}s')
print(f'\n  CV F1:  {cv_f1:.4f} (Exp1: 0.9354, Δ = {cv_f1 - 0.9354:.4f})')
print(f'  CV MCC: {cv_mcc:.4f} (Exp1: 0.8751, Δ = {cv_mcc - 0.8751:.4f})')

#  Predict
print('\n[6/9] Predictions...')
y_train_pred_proba = xgb_model.predict_proba(X_train_balanced)[:, 1]
y_test_pred_proba = xgb_model.predict_proba(X_test_scaled)[:, 1]

precisions, recalls, thresholds = precision_recall_curve(y_test, y_test_pred_proba)
f1_scores = 2 * (precisions[:-1] * recalls[:-1]) / (precisions[:-1] + recalls[:-1] + 1e-10)
optimal_idx = np.argmax(f1_scores)
optimal_threshold = thresholds[optimal_idx]
print(f' Threshold: {optimal_threshold:.4f}')

y_test_pred = (y_test_pred_proba >= optimal_threshold).astype(int)
y_train_pred = (y_train_pred_proba >= optimal_threshold).astype(int)

#  Metrics
print('\n[7/9] Metrics...')
train_acc = accuracy_score(y_train_balanced, y_train_pred)
train_f1 = f1_score(y_train_balanced, y_train_pred)
train_mcc = matthews_corrcoef(y_train_balanced, y_train_pred)
train_auc = roc_auc_score(y_train_balanced, y_train_pred_proba)

test_acc = accuracy_score(y_test, y_test_pred)
test_f1 = f1_score(y_test, y_test_pred)
test_prec = precision_score(y_test, y_test_pred)
test_rec = recall_score(y_test, y_test_pred)
test_auc = roc_auc_score(y_test, y_test_pred_proba)
test_mcc = matthews_corrcoef(y_test, y_test_pred)

print('\n' + '='*70)
print('EXPERIMENT 2: XGBOOST (PRODUCTION FEATURES ONLY)')
print('='*70)
print(f'\nCV (5-Fold):  F1={cv_f1:.4f}, MCC={cv_mcc:.4f}')
print(f'Train:        F1={train_f1:.4f}, MCC={train_mcc:.4f}, AUC={train_auc:.4f}')
print(f'Test:         F1={test_f1:.4f}, Prec={test_prec:.4f}, Rec={test_rec:.4f}')
print(f'              MCC={test_mcc:.4f}, AUC={test_auc:.4f}')
print(f'\nEXP 1 (8 feat):  Test F1=0.7626, MCC=0.7673, AUC=0.9606')
print(f'EXP 2 (4 feat):  Test F1={test_f1:.4f}, MCC={test_mcc:.4f}, AUC={test_auc:.4f}')
print(f'PERFORMANCE DROP: ΔF1={test_f1-0.7626:.4f} ({((test_f1-0.7626)/0.7626*100):.1f}%)')
print('='*70)

print('\nFeature Importances:')
feat_imp = pd.DataFrame({
    'feature': X_train.columns,
    'importance': xgb_model.feature_importances_
}).sort_values('importance', ascending=False)
print(feat_imp.to_string(index=False))

cm = confusion_matrix(y_test, y_test_pred)
print(f'\nConfusion: TN={cm[0,0]:,}, FP={cm[0,1]:,}, FN={cm[1,0]:,}, TP={cm[1,1]:,}')
print(f'Frauds Caught: {cm[1,1]}/{cm[1,0]+cm[1,1]} ({cm[1,1]/(cm[1,0]+cm[1,1])*100:.1f}%)')
print(f'False Alarms: {cm[0,1]:,}')


#  ROC
print('\n ROC Curve...')
fig, train_gini, test_gini = plot_gini(
    y_train_balanced, y_train_pred_proba, y_test, y_test_pred_proba, 'XGBoost (Exp 2)'
)
plt.savefig('/Users/henriette/Desktop/Dissertation/Results/exp2_xgb_roc.png', dpi=300, bbox_inches='tight')
print(f'✓ Saved. Train Gini={train_gini:.1f}%, Test Gini={test_gini:.1f}%')
plt.show()

# Save
pd.DataFrame([{
    'Model': 'XGBoost', 'Experiment': 'Experiment 2 (4 features)',
    'Features_Used': 4, 'CV_F1': cv_f1, 'CV_MCC': cv_mcc,
    'Test_F1': test_f1, 'Test_MCC': test_mcc, 'Test_AUC': test_auc,
    'Threshold': optimal_threshold, 'Train_Time': train_time,
    'Train_Gini': train_gini, 'Test_Gini': test_gini
}]).to_csv('/Users/henriette/Desktop/Dissertation/Results/exp2_xgb_metrics.csv', index=False)

print('\nXGBoost (Exp 2) COMPLETE')
print('='*70)


print('\n[BONUS] Creating confusion matrix and feature importance...')

# Get confusion matrix with percentages
cm_percent = cm.astype(float) / cm.sum(axis=1)[:, np.newaxis] * 100

# Create side-by-side plot
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(16, 6))

# 1. CONFUSION MATRIX
sns.heatmap(cm, annot=True, fmt='d', cmap='Oranges', ax=ax1,
            xticklabels=['Legitimate', 'Fraud'],
            yticklabels=['Legitimate', 'Fraud'])
for i in range(cm.shape[0]):
    for j in range(cm.shape[1]):
        ax1.text(j+0.5, i+0.7, f'({cm_percent[i,j]:.2f}%)', 
                ha='center', va='center', fontsize=10, color='gray')

ax1.set_title("Confusion Matrix - XGBoost (Exp 2)\n5 Production Features - NO Temporal Leakage", 
             fontsize=14, fontweight='bold')
ax1.set_ylabel('Actual', fontsize=12)
ax1.set_xlabel('Predicted', fontsize=12)

# Add performance stats
stats_text = f"Frauds Caught: {cm[1,1]}/{cm[1,0]+cm[1,1]} ({cm[1,1]/(cm[1,0]+cm[1,1])*100:.1f}%)\n"
stats_text += f"False Alarms: {cm[0,1]}\n"
stats_text += f"F1 Score: {test_f1:.4f}"
ax1.text(0.5, -0.15, stats_text, transform=ax1.transAxes, 
         fontsize=11, ha='center', bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.5))

# 2. FEATURE IMPORTANCE
feat_imp_sorted = feat_imp.sort_values('importance', ascending=True)
colors = ['#ff7f0e', '#ff7f0e', '#ff7f0e', '#ff7f0e', '#ff7f0e']
ax2.barh(feat_imp_sorted['feature'], feat_imp_sorted['importance'], color=colors)
ax2.set_title('Feature Importances\n(Production Features Only)', 
             fontsize=14, fontweight='bold')
ax2.set_xlabel('Importance', fontsize=12)
ax2.set_ylabel('Feature', fontsize=12)
ax2.grid(axis='x', alpha=0.3)

# Add percentage labels on bars
for idx, (feat, imp) in enumerate(zip(feat_imp_sorted['feature'], feat_imp_sorted['importance'])):
    ax2.text(imp + 0.01, idx, f'{imp*100:.1f}%', va='center', fontsize=10)

plt.tight_layout()
plt.savefig('/Users/henriette/Desktop/Dissertation/Results/exp2_xgb_confusion_feature_importance.png', 
            dpi=300, bbox_inches='tight')
print(' Confusion matrix and feature importance saved')
plt.show()

