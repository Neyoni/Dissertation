#Importing necessary libraries
import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib as plt

#Loading data
df=pd.read_csv('/Users/henriette/Desktop/Dissertation/Data/Paysim.csv')

#Basic Information
print("Dataset shape:", df.shape)
print("\nColumn Names:")
print(df.columns.to_list())
print("\nFirst 5 Rows:")
print(df.head())
print("\nData Types:")
print(df.dtypes)
print("\nMissing values:")
print(df.isnull().sum())
print("\nBasic Statistics")
print(df.describe())

#Checking Fraud distribution
print("\nFraud Distribution:")
print(df['isFraud'].value_counts())
print("\n Fraud rate: {df['isFraud'].mean()*100:.4f}%")

#Feature Section for experiment 1
#Lokonan's replication.

#select features
feature_cols = ['step', 'type', 'amount', 'oldbalanceOrg', 'newbalanceOrig', 'oldbalanceDest', 'newbalanceDest']

X = df[feature_cols].copy()
y = df['isFraud'].copy()

print('Features Selected:')
print(X.columns.tolist())
print('\nFeature data types:')
print(X.dtypes)


#Checking for issues
print('\nChecking for infinite values:')
print(np.isinf(X.select_dtypes(include=[np.number])).sum())

print('\nChecking for missing values:')
print(X.isnull().sum())

#One hot encoding for column 'type'
from sklearn.preprocessing import LabelEncoder, OneHotEncoder
import pandas as pd

#Checking for unique values in column 'type'
print('Transaction Type:')
print(X['type'].value_counts())

#One hot encoding 'type'
X_encoded = pd.get_dummies(X, columns=['type'], prefix='type', drop_first= False)

print('\nAfter one hot encoding:')
print(f'Number of features: {X_encoded.shape[1]}')
print("\nFeature name:")
print(X_encoded.columns.tolist())

#verify encoding works
print("\nFirst 5 rows:")
print(X_encoded.head())

#Train/Test Split
from sklearn.model_selection import train_test_split

#split data (60/40, stratefied)
X_train, X_test, y_train, y_test = train_test_split(
    X_encoded,
    y,
    test_size=0.4,
    random_state=42,
    stratify=y
)

print('Training set')
print(f'X_train.shape: {X_train.shape}')
print(f'y_train.shape: {y_train.shape}')
print(f'fraud rate: {y_train.mean()*100:.4f}%')

print('\nTesting set')
print(f'X_test.shape: {X_test.shape}')
print(f'y_test.shape: {y_test.shape}')
print(f'fraud_rate: {y_test.mean()*100:.4f}%')

# Checking that stratification worked. i.e fraud rates should be similar
assert abs (y_train.mean() - y_test.mean()) < 0.0001, 'Stratification Failed'
print('\nStratification successful - fraud rate match')

#Saving preprocessed data
X_train.to_csv('/Users/henriette/Desktop/Dissertation/Data/X_train_exp1.csv', index=False)
X_test.to_csv('/Users/henriette/Desktop/Dissertation/Data/X_test_exp1.csv', index=False)
y_train.to_csv('/Users/henriette/Desktop/Dissertation/Data/y_train_exp1.csv', index=False)
y_test.to_csv('/Users/henriette/Desktop/Dissertation/Data/y_test_exp1.csv', index=False)

print('Preprocessing complete, model ready for training')