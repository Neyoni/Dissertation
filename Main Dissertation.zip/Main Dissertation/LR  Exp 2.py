# ============================================
# LOGISTIC REGRESSION - EXPERIMENT 2
# Production Features Only (NO Temporal Leakage)
# ============================================

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import MinMaxScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (classification_report, confusion_matrix, 
                             f1_score, matthews_corrcoef, roc_auc_score, roc_curve)
from sklearn.model_selection import cross_val_score, GridSearchCV
from imblearn.combine import SMOTEENN
import time
import warnings
warnings.filterwarnings('ignore')

print('='*70)
print("EXPERIMENT 2: LOGISTIC REGRESSION - PRODUCTION FEATURES")
print("5 Features - NO Temporal Leakage")
print('='*70)

# ============================================
#  LOAD DATA
# ============================================

print('\nLoading data...')

X_train_full = pd.read_csv('/Users/henriette/Desktop/Dissertation/Data/X_train_exp1.csv')
X_test_full = pd.read_csv('/Users/henriette/Desktop/Dissertation/Data/X_test_exp1.csv')
y_train = pd.read_csv('/Users/henriette/Desktop/Dissertation/Data/y_train_exp1.csv').squeeze()
y_test = pd.read_csv('/Users/henriette/Desktop/Dissertation/Data/y_test_exp1.csv').squeeze()

print(f' Original data loaded: {X_train_full.shape[0]:,} train, {X_test_full.shape[0]:,} test')

# Select production features only
production_features = ['amount', 'type_TRANSFER', 'type_PAYMENT', 'type_CASH_OUT', 'type_CASH_IN']
X_train = X_train_full[production_features].copy()
X_test = X_test_full[production_features].copy()

print(f' Production features selected: {len(production_features)} features')
print(f'  Features: {production_features}')

# ============================================
# SCALE DATA
# ============================================

print('\n Applying MinMaxScaler...')

scaler = MinMaxScaler()
X_train_scaled = pd.DataFrame(scaler.fit_transform(X_train), columns=X_train.columns)
X_test_scaled = pd.DataFrame(scaler.transform(X_test), columns=X_test.columns)

print(' Scaled')

# ============================================
# APPLY SMOTE-ENN
# ============================================

print('\n Applying SMOTE-ENN...')
start_smote = time.time()

smote_enn = SMOTEENN(random_state=42, n_jobs=-1)
X_train_balanced, y_train_balanced = smote_enn.fit_resample(X_train_scaled, y_train)

print(f'✓ SMOTE-ENN: {time.time()-start_smote:.1f}s')
print(f'  Original: {len(X_train_scaled):,} samples')
print(f'  Balanced: {len(X_train_balanced):,} samples')
print(f'  Class distribution: {np.bincount(y_train_balanced)}')

# ============================================
#  GRID SEARCH 
# ============================================

print('\n Grid Search for hyperparameters...')

param_grid = {
    'C': [0.01, 1.0, 10.0],
    'penalty': ['l1', 'l2']
}

lr = LogisticRegression(
    solver='saga',
    max_iter=1000,
    random_state=42,
    n_jobs=4
)

start_grid = time.time()

grid_search = GridSearchCV(
    lr, 
    param_grid, 
    cv=3,  # Reduced to 3 for speed
    scoring='f1',
    n_jobs=4,
    verbose=0
)

grid_search.fit(X_train_balanced, y_train_balanced)

print(f'  Grid Search: {time.time()-start_grid:.1f}s')
print(f'  Best params: {grid_search.best_params_}')
print(f'  Best CV F1: {grid_search.best_score_:.4f}')

best_model = grid_search.best_estimator_

# ============================================
# [5/9] 5-FOLD CROSS-VALIDATION
# ============================================

print('\n 5-Fold Cross-Validation...')
start_cv = time.time()

cv_f1 = cross_val_score(best_model, X_train_balanced, y_train_balanced, 
                        cv=5, scoring='f1', n_jobs=4)
cv_mcc = cross_val_score(best_model, X_train_balanced, y_train_balanced, 
                         cv=5, scoring='matthews_corrcoef', n_jobs=4)

print(f'✓ Cross-validation: {time.time()-start_cv:.1f}s')
print(f'  CV F1:  {cv_f1.mean():.4f} (±{cv_f1.std():.4f})')
print(f'  CV MCC: {cv_mcc.mean():.4f} (±{cv_mcc.std():.4f})')

# ============================================
#  TRAIN FINAL MODEL
# ============================================

print('\n Training final model with best parameters...')
start_train = time.time()

best_model.fit(X_train_balanced, y_train_balanced)

print(f' Training: {time.time()-start_train:.1f}s')

# ============================================
#  PREDICTIONS
# ============================================

print('\n Making predictions...')

y_train_pred = best_model.predict(X_train_balanced)
y_test_pred = best_model.predict(X_test_scaled)

y_train_proba = best_model.predict_proba(X_train_balanced)[:, 1]
y_test_proba = best_model.predict_proba(X_test_scaled)[:, 1]

print('Predictions complete')

# ============================================
#  CALCULATE METRICS
# ============================================

print('\n Calculating metrics...')

# Confusion matrices
cm_train = confusion_matrix(y_train_balanced, y_train_pred)
cm_test = confusion_matrix(y_test, y_test_pred)

# Metrics
train_f1 = f1_score(y_train_balanced, y_train_pred)
test_f1 = f1_score(y_test, y_test_pred)

train_mcc = matthews_corrcoef(y_train_balanced, y_train_pred)
test_mcc = matthews_corrcoef(y_test, y_test_pred)

train_auc = roc_auc_score(y_train_balanced, y_train_proba)
test_auc = roc_auc_score(y_test, y_test_proba)

# Classification report
test_report = classification_report(y_test, y_test_pred, output_dict=True)

print('\n' + '='*70)
print('EXPERIMENT 2: LOGISTIC REGRESSION (PRODUCTION FEATURES)')
print('='*70)

print(f'\nCV:     F1={cv_f1.mean():.4f}, MCC={cv_mcc.mean():.4f}')
print(f'Train:  F1={train_f1:.4f}, MCC={train_mcc:.4f}, AUC={train_auc:.4f}')
print(f'Test:   F1={test_f1:.4f}, MCC={test_mcc:.4f}, AUC={test_auc:.4f}')
print(f'\nPrecision: {test_report["1"]["precision"]:.4f}')
print(f'Recall:    {test_report["1"]["recall"]:.4f}')

print('\nConfusion Matrix (Test):')
print(f'  TN={cm_test[0,0]:,}, FP={cm_test[0,1]:,}')
print(f'  FN={cm_test[1,0]:,}, TP={cm_test[1,1]:,}')

# Compare to Exp 1
print('\n' + '-'*70)
print('COMPARISON TO EXPERIMENT 1:')
print('-'*70)
print('EXP 1 (8 features): Test F1=0.6988, MCC=0.7099, AUC=0.9319')
print(f'EXP 2 (5 features): Test F1={test_f1:.4f}, MCC={test_mcc:.4f}, AUC={test_auc:.4f}')
print(f'PERFORMANCE DROP:   F1={test_f1-0.6988:.4f} ({((test_f1-0.6988)/0.6988)*100:.1f}%)')
print('='*70)

# ============================================
#  VISUALIZATIONS & SAVE
# ============================================

print('\n Creating visualizations...')

# ROC Curve
fpr_train, tpr_train, _ = roc_curve(y_train_balanced, y_train_proba)
fpr_test, tpr_test, _ = roc_curve(y_test, y_test_proba)

gini_train = 2 * train_auc - 1
gini_test = 2 * test_auc - 1

plt.figure(figsize=(10, 8))
plt.plot(fpr_test, tpr_test, 'g-', linewidth=2, 
         label=f'Test (GINI = {gini_test*100:.1f}%, AUC = {test_auc:.4f})')
plt.plot(fpr_train, tpr_train, 'r-', linewidth=2, 
         label=f'Train (GINI = {gini_train*100:.1f}%, AUC = {train_auc:.4f})')
plt.plot([0, 1], [0, 1], 'b--', linewidth=2, label='Random (GINI = 0%)')
plt.xlim([-0.01, 1.01])
plt.ylim([-0.01, 1.01])
plt.xlabel('False Positive Rate', fontsize=12)
plt.ylabel('True Positive Rate', fontsize=12)
plt.title('ROC Curve - Logistic Regression (Experiment 2: Production Features Only)', 
          fontsize=14, fontweight='bold')
plt.legend(loc='lower right', fontsize=11)
plt.grid(alpha=0.3)
plt.tight_layout()
plt.savefig('/Users/henriette/Desktop/Dissertation/Results/roc_lr_exp2.png', 
            dpi=300, bbox_inches='tight')
plt.show()
print('   ROC curve saved')

# Confusion Matrix
fig, axes = plt.subplots(1, 2, figsize=(14, 6))

cm_test_pct = cm_test.astype('float') / cm_test.sum(axis=1)[:, np.newaxis] * 100
sns.heatmap(cm_test, annot=True, fmt='d', cmap='Blues', ax=axes[0], 
            cbar=False, square=True, linewidths=2)
axes[0].set_title('Logistic Regression Exp 2\nConfusion Matrix', 
                  fontsize=13, fontweight='bold')
axes[0].set_ylabel('Actual', fontsize=11)
axes[0].set_xlabel('Predicted', fontsize=11)
axes[0].set_xticklabels(['Legitimate', 'Fraud'])
axes[0].set_yticklabels(['Legitimate', 'Fraud'])

for i in range(2):
    for j in range(2):
        axes[0].text(j+0.5, i+0.7, f'({cm_test_pct[i,j]:.1f}%)', 
                    ha='center', va='center', fontsize=10, color='darkblue')

# Feature coefficients
coef_df = pd.DataFrame({
    'feature': X_train.columns,
    'coefficient': best_model.coef_[0]
}).sort_values('coefficient', ascending=True)

axes[1].barh(coef_df['feature'], coef_df['coefficient'], color='steelblue', edgecolor='black')
axes[1].set_xlabel('Coefficient', fontsize=11)
axes[1].set_title('Logistic Regression Coefficients\n(Production Features)', 
                  fontsize=13, fontweight='bold')
axes[1].grid(axis='x', alpha=0.3)
axes[1].axvline(x=0, color='red', linestyle='--', linewidth=1)

plt.suptitle('Logistic Regression - Experiment 2 (5 Production Features)', 
             fontsize=15, fontweight='bold', y=1.02)
plt.tight_layout()
plt.savefig('/Users/henriette/Desktop/Dissertation/Results/confusion_coef_lr_exp2.png', 
            dpi=300, bbox_inches='tight')
plt.show()
print('   Confusion matrix saved')

# Save metrics
metrics_summary = {
    'model': 'Logistic_Regression',
    'experiment': 'Exp2_Production',
    'features': 5,
    'cv_f1': cv_f1.mean(),
    'train_f1': train_f1,
    'test_f1': test_f1,
    'train_mcc': train_mcc,
    'test_mcc': test_mcc,
    'train_auc': train_auc,
    'test_auc': test_auc,
    'test_precision': test_report["1"]["precision"],
    'test_recall': test_report["1"]["recall"],
    'frauds_caught': int(cm_test[1,1]),
    'frauds_total': int(cm_test[1,0] + cm_test[1,1]),
    'false_alarms': int(cm_test[0,1]),
    'best_C': grid_search.best_params_['C'],
    'best_penalty': grid_search.best_params_['penalty']
}

pd.DataFrame([metrics_summary]).to_csv(
    '/Users/henriette/Desktop/Dissertation/Results/exp2_lr_metrics.csv', 
    index=False
)

print(' Metrics saved')

print('\n' + '='*70)
print('LOGISTIC REGRESSION (EXP 2) COMPLETE')
print('='*70)