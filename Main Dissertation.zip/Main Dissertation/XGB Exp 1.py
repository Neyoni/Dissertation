#importing neccessary libraries
import numpy as np
import pandas as pd
from xgboost import XGBClassifier
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import cross_val_score
from imblearn.combine import SMOTEENN
from sklearn.metrics import (classification_report, confusion_matrix, f1_score, 
                             precision_score, recall_score, roc_auc_score, roc_curve, auc,
                             matthews_corrcoef, accuracy_score, precision_recall_curve,
                             make_scorer)
import matplotlib.pyplot as plt
import seaborn as sns
from datetime import datetime
import warnings
warnings.filterwarnings('ignore')


# HELPER FUNCTIONS


def gini(y_true, y_pred, sample=None):
    fpr, tpr, _ = roc_curve(y_true, y_pred)
    gini_score = 100 * (2 * auc(fpr, tpr) - 1)
    if sample:
        print(f'Gini on {sample} = {gini_score:.1f}%')
    return gini_score, fpr, tpr

def plot_gini(y_true_train, y_pred_train, y_true_test, y_pred_test, model_name='Model'):
    fig = plt.figure(figsize=(10, 7))
    ax = fig.add_subplot(1, 1, 1)
    train_gini, fpr_train, tpr_train = gini(y_true_train, y_pred_train)
    test_gini, fpr_test, tpr_test = gini(y_true_test, y_pred_test)
    
    ax.plot(fpr_test, tpr_test, color='green', linewidth=2.5, 
            label=f'Test (GINI = {test_gini:.1f}%, AUC = {(test_gini/100 + 1)/2:.4f})')
    ax.plot(fpr_train, tpr_train, color='red', linewidth=2.5, 
            label=f'Train (GINI = {train_gini:.1f}%, AUC = {(train_gini/100 + 1)/2:.4f})')
    ax.plot([0, 1], [0, 1], color='navy', lw=2, linestyle='--', label='Random (GINI = 0%)')
    
    ax.set_xlabel('False Positive Rate', fontsize=12)
    ax.set_ylabel('True Positive Rate', fontsize=12)
    ax.set_title(f'ROC Curve - {model_name}\n(Experiment 1: 5-Fold CV)', 
                 fontsize=14, fontweight='bold')
    ax.legend(loc="lower right", frameon=True, fontsize=11)
    ax.grid(alpha=0.3)
    
    plt.tight_layout()
    return fig, train_gini, test_gini

print('='*70)
print("Experiment 1: XGBoost - Gradient Boosting")
print("5-FOLD CV + ROC CURVES + GINI COEFFICIENT")
print('='*70)

# Loading preprocessed data


print('\n[1/9] Loading preprocessed data...')
X_train = pd.read_csv('/Users/henriette/Desktop/Dissertation/Data/X_train_exp1.csv')
X_test = pd.read_csv('/Users/henriette/Desktop/Dissertation/Data/X_test_exp1.csv')
y_train = pd.read_csv('/Users/henriette/Desktop/Dissertation/Data/y_train_exp1.csv').squeeze()
y_test = pd.read_csv('/Users/henriette/Desktop/Dissertation/Data/y_test_exp1.csv').squeeze()

print(f'Training set: {X_train.shape[0]:,} samples, {X_train.shape[1]} features')
print(f'Test set: {X_test.shape[0]:,} samples, {X_test.shape[1]} features')
print(f'Training fraud rate: {y_train.mean()*100:.4f}%')
print(f'Test fraud rate: {y_test.mean()*100:.4f}%')

if X_train.shape[1] == 8:
    print('CORRECT: 8 features (matching Lokanan Figure 2)')

# Applying MinMaxScaler
scaler = MinMaxScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

X_train_scaled = pd.DataFrame(X_train_scaled, columns=X_train.columns)
X_test_scaled = pd.DataFrame(X_test_scaled, columns=X_test.columns)

print('Features scaled to range [0, 1]')

# Applying SMOTE-ENN
smote_start = datetime.now()
smote_enn = SMOTEENN(random_state=42, n_jobs=-1)
X_train_balanced, y_train_balanced = smote_enn.fit_resample(X_train_scaled, y_train)
smote_time = (datetime.now() - smote_start).total_seconds()

print(f'✓ SMOTE-ENN complete in: {smote_time:.1f} seconds ({smote_time/60:.1f} minutes)')
print(f'  After SMOTE: {len(y_train_balanced):,} samples ({y_train_balanced.mean()*100:.2f}% fraud)')

# Training XGBoost

print('Parameters: n_estimators=100, max_depth=5, learning_rate=0.1')

train_start = datetime.now()

xgb_model = XGBClassifier(
    n_estimators=100,        # Similar to RF
    max_depth=5,             # Same as RF for fair comparison
    learning_rate=0.1,       # Standard learning rate
    subsample=0.8,           # Use 80% of data per tree
    colsample_bytree=0.8,    # Use 80% of features per tree
    random_state=42,
    n_jobs=4,
    eval_metric='logloss',   # Suppress warnings
    use_label_encoder=False
)

xgb_model.fit(X_train_balanced, y_train_balanced)

train_time = (datetime.now() - train_start).total_seconds()
print(f'\n Training complete in {train_time:.1f} seconds ({train_time/60:.1f} minutes)')


#  Cross-Validation (5-Fold)

print('\n Calculating 5-fold CV scores...')

cv_start = datetime.now()

# F1 score
cv_f1_scores = cross_val_score(xgb_model, X_train_balanced, y_train_balanced, 
                               cv=5, scoring='f1', n_jobs=4, verbose=0)
cv_f1 = cv_f1_scores.mean()
cv_f1_std = cv_f1_scores.std()

# MCC score
mcc_scorer = make_scorer(matthews_corrcoef)
cv_mcc_scores = cross_val_score(xgb_model, X_train_balanced, y_train_balanced,
                                cv=5, scoring=mcc_scorer, n_jobs=4, verbose=0)
cv_mcc = cv_mcc_scores.mean()
cv_mcc_std = cv_mcc_scores.std()

cv_time = (datetime.now() - cv_start).total_seconds()

print(f' CV complete in {cv_time:.1f} seconds ({cv_time/60:.1f} minutes)')
print(f'\nBest 5-Fold CV F1 score: {cv_f1:.4f}')
print(f'  Random Forest CV F1: 0.9068')
print(f'  Difference: {cv_f1 - 0.9068:.4f}')

if cv_f1 >= 0.85:
    print(f'CV F1 in excellent range!')

print(f'\nCalculating 5-Fold CV MCC...')
print(f'  CV MCC: {cv_mcc:.4f} (±{cv_mcc_std:.4f})')
print(f'  Random Forest CV MCC: 0.8248')
print(f'  Difference: {cv_mcc - 0.8248:.4f}')


# Making predictions on train and test sets

# Train predictions (for ROC curve comparison)
y_train_pred_proba = xgb_model.predict_proba(X_train_balanced)[:, 1]

# Test predictions
y_test_pred_proba = xgb_model.predict_proba(X_test_scaled)[:, 1]

print('Predictions complete')

#  Finding F1-optimal threshold on test set(F1-Maximizing)

precisions, recalls, thresholds = precision_recall_curve(y_test, y_test_pred_proba)
f1_scores = 2 * (precisions[:-1] * recalls[:-1]) / (precisions[:-1] + recalls[:-1] + 1e-10)

optimal_idx = np.argmax(f1_scores)
optimal_threshold = thresholds[optimal_idx]
optimal_precision = precisions[optimal_idx]
optimal_recall = recalls[optimal_idx]
optimal_f1 = f1_scores[optimal_idx]

print(f' F1-Optimal threshold: {optimal_threshold:.4f}')
print(f'  Expected Performance:')
print(f'    Precision: {optimal_precision:.4f}')
print(f'    Recall: {optimal_recall:.4f}')
print(f'    F1: {optimal_f1:.4f}')

# Apply optimal threshold
y_test_pred_optimal = (y_test_pred_proba >= optimal_threshold).astype(int)
y_train_pred_optimal = (y_train_pred_proba >= optimal_threshold).astype(int)

print(f'\nTest set predictions:')
print(f'  Predicted {y_test_pred_optimal.sum():,} frauds out of {len(y_test):,}')
print(f'  Prediction rate: {y_test_pred_optimal.mean()*100:.4f}%')


# Calculating final metrics

# Test metrics
test_accuracy = accuracy_score(y_test, y_test_pred_optimal)
test_f1 = f1_score(y_test, y_test_pred_optimal)
test_precision = precision_score(y_test, y_test_pred_optimal)
test_recall = recall_score(y_test, y_test_pred_optimal)
test_roc_auc = roc_auc_score(y_test, y_test_pred_proba)
test_mcc = matthews_corrcoef(y_test, y_test_pred_optimal)

# Train metrics (for comparison)
train_accuracy = accuracy_score(y_train_balanced, y_train_pred_optimal)
train_f1 = f1_score(y_train_balanced, y_train_pred_optimal)
train_mcc = matthews_corrcoef(y_train_balanced, y_train_pred_optimal)
train_roc_auc = roc_auc_score(y_train_balanced, y_train_pred_proba)

print('\n' + '='*70)
print('XGBOOST RESULTS - EXPERIMENT 1')
print('='*70)

print(f'\nCROSS-VALIDATION (5-Fold on SMOTE-Balanced Training):')
print(f'  CV F1:  {cv_f1:.4f} (RF: 0.9068)')
print(f'  CV MCC: {cv_mcc:.4f} (RF: 0.8248)')

print(f'\nTRAINING SET (SMOTE-Balanced, threshold={optimal_threshold:.4f}):')
print(f'  Train Accuracy: {train_accuracy:.4f}')
print(f'  Train F1:       {train_f1:.4f}')
print(f'  Train MCC:      {train_mcc:.4f}')
print(f'  Train ROC-AUC:  {train_roc_auc:.4f}')

print(f'\nTEST SET (Imbalanced, threshold={optimal_threshold:.4f}):')
print(f'{"Metric":<15} {"Your Result":<12} {"RF Result":<12} {"Δ"}')
print('-'*50)
print(f'{"Accuracy":<15} {test_accuracy:<12.4f} {"0.9994":<12} {test_accuracy-0.9994:.4f}')
print(f'{"Precision":<15} {test_precision:<12.4f} {"0.9335":<12} {test_precision-0.9335:.4f}')
print(f'{"Recall":<15} {test_recall:<12.4f} {"0.5701":<12} {test_recall-0.5701:.4f}')
print(f'{"F1":<15} {test_f1:<12.4f} {"0.7079":<12} {test_f1-0.7079:.4f}')
print(f'{"MCC":<15} {test_mcc:<12.4f} {"0.7293":<12} {test_mcc-0.7293:.4f}')
print(f'{"ROC-AUC":<15} {test_roc_auc:<12.4f} {"0.9651":<12} {test_roc_auc-0.9651:.4f}')
print('='*70)

if cv_f1 >= 0.90:
    print('\n CV F1 exceeds Random Forest!')
elif cv_f1 >= 0.85:
    print('\n CV F1 in excellent range!')
    
print('\nDetailed Classification Report:')
print(classification_report(y_test, y_test_pred_optimal, 
                           target_names=['Legitimate', 'Fraud'], 
                           digits=4))

# Feature Importance
print('\nTop 10 Feature Importances:')
feature_importance = pd.DataFrame({
    'feature': X_train.columns,
    'importance': xgb_model.feature_importances_
}).sort_values('importance', ascending=False)

print(feature_importance.head(10).to_string(index=False))

# Confusion Matrix
cm = confusion_matrix(y_test, y_test_pred_optimal)
cm_percent = cm.astype(float) / cm.sum(axis=1)[:, np.newaxis] * 100

print(f'\nConfusion Matrix:')
print(f'  True Negatives:  {cm[0,0]:,} ({cm_percent[0,0]:.2f}%)')
print(f'  False Positives: {cm[0,1]:,} ({cm_percent[0,1]:.2f}%)')
print(f'  False Negatives: {cm[1,0]:,} ({cm_percent[1,0]:.2f}%)')
print(f'  True Positives:  {cm[1,1]:,} ({cm_percent[1,1]:.2f}%)')

# Generating ROC curve with Gini coefficient

fig_roc, train_gini, test_gini = plot_gini(
    y_train_balanced, y_train_pred_proba,
    y_test, y_test_pred_proba,
    model_name='XGBoost'
)

plt.savefig('/Users/henriette/Desktop/Dissertation/Results/exp1_xgb_roc_curve.png', 
            dpi=300, bbox_inches='tight')
print(f'  ROC curve saved')
print(f'  Train Gini: {train_gini:.1f}% (ROC-AUC: {train_roc_auc:.4f})')
print(f'  Test Gini:  {test_gini:.1f}% (ROC-AUC: {test_roc_auc:.4f})')
plt.show()

# Confusion Matrix + Feature Importance Plot
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(16, 6))

# Confusion Matrix
sns.heatmap(cm, annot=True, fmt='d', cmap='Oranges', ax=ax1,
            xticklabels=['Legitimate', 'Fraud'],
            yticklabels=['Legitimate', 'Fraud'])
for i in range(cm.shape[0]):
    for j in range(cm.shape[1]):
        ax1.text(j+0.5, i+0.7, f'({cm_percent[i,j]:.2f}%)', 
                ha='center', va='center', fontsize=10, color='gray')
ax1.set_title("Confusion Matrix - XGBoost\n(Experiment 1: 5-Fold CV)", 
             fontsize=14, fontweight='bold')
ax1.set_ylabel('Actual', fontsize=12)
ax1.set_xlabel('Predicted', fontsize=12)

# Feature Importance
feature_importance.head(8).plot(kind='barh', x='feature', y='importance', ax=ax2, 
                                legend=False, color='orange')
ax2.set_title('Top 8 Feature Importances', fontsize=14, fontweight='bold')
ax2.set_xlabel('Importance', fontsize=12)
ax2.invert_yaxis()

plt.tight_layout()
plt.savefig('/Users/henriette/Desktop/Dissertation/Results/exp1_xgb_confusion_feature_importance.png', 
            dpi=300, bbox_inches='tight')
print(' Confusion matrix and feature importance saved')
plt.show()


# Save predictions
results_df = pd.DataFrame({
    'y_true': y_test.values,
    'y_pred': y_test_pred_optimal,
    'y_pred_proba': y_test_pred_proba
})
results_df.to_csv('/Users/henriette/Desktop/Dissertation/Results/exp1_xgb_predictions.csv', index=False)

# Save metrics summary
metrics_summary = {
    'Model': 'XGBoost',
    'Experiment': 'Experiment 1 (5-Fold CV)',
    'Features_Used': X_train.shape[1],
    'n_estimators': 100,
    'max_depth': 5,
    'learning_rate': 0.1,
    'CV_F1_Score': cv_f1,
    'CV_MCC_Score': cv_mcc,
    'Train_Accuracy': train_accuracy,
    'Train_F1': train_f1,
    'Train_MCC': train_mcc,
    'Train_ROC_AUC': train_roc_auc,
    'Train_Gini': train_gini,
    'Optimal_Threshold': optimal_threshold,
    'Test_Accuracy': test_accuracy,
    'Test_Precision': test_precision,
    'Test_Recall': test_recall,
    'Test_F1_Score': test_f1,
    'Test_MCC': test_mcc,
    'Test_ROC_AUC': test_roc_auc,
    'Test_Gini': test_gini,
    'Training_Time_Seconds': train_time,
    'CV_Time_Seconds': cv_time,
    'SMOTE_Time_Seconds': smote_time,
    'Date': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
}

pd.DataFrame([metrics_summary]).to_csv(
    '/Users/henriette/Desktop/Dissertation/Results/exp1_xgb_metrics.csv', 
    index=False
)

print('\n Results saved')
print('\n' + '='*70)
print('XGBOOST COMPLETE')
print('='*70)