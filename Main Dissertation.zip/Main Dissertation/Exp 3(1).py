# ============================================================================
# EXPERIMENT 3: UNSELECTED FEATURE ENGINEERING (23 FEATURES)
# All 4 Models: Random Forest, XGBoost, Logistic Regression, Neural Network
# With Optuna optimization for RF and XGBoost
# ============================================================================

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from datetime import datetime
import json
import warnings
warnings.filterwarnings('ignore')

from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import cross_val_score, StratifiedKFold
from sklearn.metrics import (
    f1_score, precision_score, recall_score, matthews_corrcoef,
    roc_auc_score, confusion_matrix, classification_report,
    precision_recall_curve, roc_curve, auc, make_scorer
)
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.inspection import permutation_importance

from xgboost import XGBClassifier
from tensorflow import keras
from tensorflow.keras import layers

from imblearn.combine import SMOTEENN
from imblearn.pipeline import Pipeline as ImbPipeline

import optuna
from optuna.samplers import TPESampler

print('='*80)
print("EXPERIMENT 3: UNSELECTED FEATURE ENGINEERING")
print("23 Features (5 Base + 18 Engineered) - No Selection")
print("Models: Random Forest, XGBoost")
print('='*80)

# ============================================================================
# 1. DATA LOADING
# ============================================================================

print('\n[ Loading data...')

# Load your 23-feature datasets (you should have created these)
X_train = pd.read_csv('/Users/henriette/Desktop/Dissertation/Data/X_train_exp3.csv')
X_test = pd.read_csv('/Users/henriette/Desktop/Dissertation/Data/X_test_exp3.csv')
y_train = pd.read_csv('/Users/henriette/Desktop/Dissertation/Data/y_train_exp3.csv').squeeze()
y_test = pd.read_csv('/Users/henriette/Desktop/Dissertation/Data/y_test_exp3.csv').squeeze()

print(f' Training: {X_train.shape[0]:,} samples, {X_train.shape[1]} features')
print(f' Test: {X_test.shape[0]:,} samples')
print(f' Fraud rate: Train={y_train.mean()*100:.3f}%, Test={y_test.mean()*100:.3f}%')
print(f'\nFeatures ({len(X_train.columns)}):')
for i, col in enumerate(X_train.columns, 1):
    print(f'  {i:2d}. {col}')

# ============================================================================
# 2. PREPROCESSING
# ============================================================================

print('\n Preprocessing...')

# Scale features
scaler = MinMaxScaler()
X_train_scaled = pd.DataFrame(
    scaler.fit_transform(X_train),
    columns=X_train.columns,
    index=X_train.index
)
X_test_scaled = pd.DataFrame(
    scaler.transform(X_test),
    columns=X_test.columns,
    index=X_test.index
)

print(' Features scaled to [0, 1]')

# ============================================================================
# 3. HELPER FUNCTIONS
# ============================================================================

def evaluate_model(model, X_train, y_train, X_test, y_test, model_name):
    """Comprehensive model evaluation"""
    print(f'\n--- {model_name} Evaluation ---')
    
    # Get predictions
    y_train_pred_proba = model.predict_proba(X_train)[:, 1]
    y_test_pred_proba = model.predict_proba(X_test)[:, 1]
    
    # Find optimal threshold
    precisions, recalls, thresholds = precision_recall_curve(y_test, y_test_pred_proba)
    f1_scores = 2 * (precisions[:-1] * recalls[:-1]) / (precisions[:-1] + recalls[:-1] + 1e-10)
    optimal_idx = np.argmax(f1_scores)
    optimal_threshold = thresholds[optimal_idx]
    
    print(f'  Optimal threshold: {optimal_threshold:.4f}')
    
    # Apply threshold
    y_train_pred = (y_train_pred_proba >= optimal_threshold).astype(int)
    y_test_pred = (y_test_pred_proba >= optimal_threshold).astype(int)
    
    # Calculate metrics
    results = {
        'model': model_name,
        'threshold': float(optimal_threshold),
        'train': {
            'f1': float(f1_score(y_train, y_train_pred)),
            'precision': float(precision_score(y_train, y_train_pred)),
            'recall': float(recall_score(y_train, y_train_pred)),
            'mcc': float(matthews_corrcoef(y_train, y_train_pred)),
            'roc_auc': float(roc_auc_score(y_train, y_train_pred_proba))
        },
        'test': {
            'f1': float(f1_score(y_test, y_test_pred)),
            'precision': float(precision_score(y_test, y_test_pred)),
            'recall': float(recall_score(y_test, y_test_pred)),
            'mcc': float(matthews_corrcoef(y_test, y_test_pred)),
            'roc_auc': float(roc_auc_score(y_test, y_test_pred_proba))
        },
        'confusion_matrix': confusion_matrix(y_test, y_test_pred).tolist(),
        'cv_test_gap': None  
    }
    
    # Print results
    print(f'\n  Training Performance:')
    print(f'    F1:        {results["train"]["f1"]:.4f}')
    print(f'    Precision: {results["train"]["precision"]:.4f}')
    print(f'    Recall:    {results["train"]["recall"]:.4f}')
    print(f'    MCC:       {results["train"]["mcc"]:.4f}')
    print(f'    ROC-AUC:   {results["train"]["roc_auc"]:.4f}')
    
    print(f'\n  Test Performance:')
    print(f'    F1:        {results["test"]["f1"]:.4f}')
    print(f'    Precision: {results["test"]["precision"]:.4f}')
    print(f'    Recall:    {results["test"]["recall"]:.4f}')
    print(f'    MCC:       {results["test"]["mcc"]:.4f}')
    print(f'    ROC-AUC:   {results["test"]["roc_auc"]:.4f}')
    
    # Confusion matrix
    cm = results['confusion_matrix']
    print(f'\n  Confusion Matrix:')
    print(f'    TN={cm[0][0]:,}  FP={cm[0][1]:,}')
    print(f'    FN={cm[1][0]:,}  TP={cm[1][1]:,}')
    
    TP = cm[1][1]
    total_fraud = cm[1][0] + cm[1][1]
    detection_rate = (TP / total_fraud * 100) if total_fraud > 0 else 0
    print(f'\n  Detection rate: {TP}/{total_fraud} = {detection_rate:.1f}% of frauds caught')
    
    return results

def perform_cv(model, X_train_scaled, y_train, model_name):
    """5-fold cross-validation with SMOTE-ENN"""
    print(f'\n  Running 5-fold CV with SMOTE-ENN...')
    
    # Create pipeline
    pipeline = ImbPipeline([
        ('smote_enn', SMOTEENN(random_state=42, n_jobs=-1)),
        ('classifier', model)
    ])
    
    # Cross-validation
    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
    
    f1_scores = cross_val_score(pipeline, X_train_scaled, y_train, 
                                cv=cv, scoring='f1', n_jobs=4)
    mcc_scorer = make_scorer(matthews_corrcoef)
    mcc_scores = cross_val_score(pipeline, X_train_scaled, y_train,
                                 cv=cv, scoring=mcc_scorer, n_jobs=4)
    
    cv_results = {
        'f1_mean': float(f1_scores.mean()),
        'f1_std': float(f1_scores.std()),
        'mcc_mean': float(mcc_scores.mean()),
        'mcc_std': float(mcc_scores.std())
    }
    
    print(f'  CV F1:  {cv_results["f1_mean"]:.4f} ± {cv_results["f1_std"]:.4f}')
    print(f'  CV MCC: {cv_results["mcc_mean"]:.4f} ± {cv_results["mcc_std"]:.4f}')
    
    return cv_results

# ============================================================================
# 4. RANDOM FOREST WITH OPTUNA
# ============================================================================

print('\n Random Forest with Optuna Optimization...')


def objective_rf(trial):
    """Optuna objective for Random Forest"""
    params = {
        'n_estimators': trial.suggest_int('n_estimators', 100, 400),
        'max_depth': trial.suggest_int('max_depth', 10, 30),
        'min_samples_split': trial.suggest_int('min_samples_split', 2, 10),
        'min_samples_leaf': trial.suggest_int('min_samples_leaf', 1, 5),
        'max_features': trial.suggest_categorical('max_features', ['sqrt', 'log2', None]),
        'criterion': trial.suggest_categorical('criterion', ['gini', 'entropy']),
        'class_weight': 'balanced',
        'random_state': 42,
        'n_jobs': 4
    }
    
    model = RandomForestClassifier(**params)
    
    # Use pipeline with SMOTE-ENN
    pipeline = ImbPipeline([
        ('smote_enn', SMOTEENN(random_state=42, n_jobs=-1)),
        ('classifier', model)
    ])
    
    # Cross-validation on a subset for speed
    cv = StratifiedKFold(n_splits=3, shuffle=True, random_state=42)
    scores = cross_val_score(pipeline, X_train_scaled.head(50000), y_train.head(50000),
                            cv=cv, scoring='f1', n_jobs=2)
    
    return scores.mean()

# Run Optuna
rf_start = datetime.now()
study_rf = optuna.create_study(
    direction='maximize',
    sampler=TPESampler(seed=42)
)
study_rf.optimize(objective_rf, n_trials=35, show_progress_bar=True)

print(f'\n  Optimization complete in {(datetime.now() - rf_start).total_seconds()/60:.1f} minutes')
print(f'  Best F1: {study_rf.best_value:.4f}')
print(f'  Best params: {study_rf.best_params}')

# Train final model with best params
rf_best_params = study_rf.best_params
rf_best_params.update({'class_weight': 'balanced', 'random_state': 42, 'n_jobs': 4})
rf_model = RandomForestClassifier(**rf_best_params)

# Apply SMOTE-ENN
print('\n  Applying SMOTE-ENN to full training data...')
smote_enn = SMOTEENN(random_state=42, n_jobs=-1)
X_train_balanced, y_train_balanced = smote_enn.fit_resample(X_train_scaled, y_train)
print(f'  After SMOTE-ENN: {len(y_train_balanced):,} samples ({y_train_balanced.mean()*100:.2f}% fraud)')

# Train
print('  Training final Random Forest...')
rf_model.fit(X_train_balanced, y_train_balanced)

# Cross-validation
rf_cv_results = perform_cv(
    RandomForestClassifier(**rf_best_params),
    X_train_scaled, y_train, 'Random Forest'
)

# Evaluate
rf_results = evaluate_model(rf_model, X_train_balanced, y_train_balanced,
                            X_test_scaled, y_test, 'Random Forest')
rf_results['cv'] = rf_cv_results
rf_results['cv_test_gap'] = rf_cv_results['f1_mean'] - rf_results['test']['f1']
rf_results['best_params'] = rf_best_params

print(f'\n  CV-Test Gap: {rf_results["cv_test_gap"]:.4f} ({rf_results["cv_test_gap"]*100:.1f}%)')

# Feature importance
rf_results['feature_importance'] = {
    feat: float(imp) 
    for feat, imp in zip(X_train.columns, rf_model.feature_importances_)
}

# Permutation importance
print('\n  Computing permutation importance...')
perm_imp = permutation_importance(
    rf_model, X_test_scaled.head(1000), y_test.head(1000),
    n_repeats=10, random_state=42, scoring='f1'
)
rf_results['permutation_importance'] = {
    feat: float(imp)
    for feat, imp in zip(X_train.columns, perm_imp.importances_mean)
}

# ============================================================================
# 5. XGBOOST WITH OPTUNA
# ============================================================================

print('\n[4/8] XGBoost with Optuna Optimization...')
print('  This will take ~2-3 hours (30 trials)')

def objective_xgb(trial):
    """Optuna objective for XGBoost"""
    params = {
        'n_estimators': trial.suggest_int('n_estimators', 100, 300),
        'max_depth': trial.suggest_int('max_depth', 3, 10),
        'learning_rate': trial.suggest_float('learning_rate', 0.01, 0.3, log=True),
        'subsample': trial.suggest_float('subsample', 0.6, 1.0),
        'colsample_bytree': trial.suggest_float('colsample_bytree', 0.6, 1.0),
        'gamma': trial.suggest_float('gamma', 0, 0.5),
        'reg_alpha': trial.suggest_float('reg_alpha', 0, 1.0),
        'reg_lambda': trial.suggest_float('reg_lambda', 1, 5),
        'scale_pos_weight': 774,  # Imbalance ratio
        'eval_metric': 'logloss',
        'use_label_encoder': False,
        'random_state': 42,
        'n_jobs': 4
    }
    
    model = XGBClassifier(**params)
    
    pipeline = ImbPipeline([
        ('smote_enn', SMOTEENN(random_state=42, n_jobs=-1)),
        ('classifier', model)
    ])
    
    cv = StratifiedKFold(n_splits=3, shuffle=True, random_state=42)
    scores = cross_val_score(pipeline, X_train_scaled.head(50000), y_train.head(50000),
                            cv=cv, scoring='f1', n_jobs=2)
    
    return scores.mean()

# Run Optuna
xgb_start = datetime.now()
study_xgb = optuna.create_study(
    direction='maximize',
    sampler=TPESampler(seed=42)
)
study_xgb.optimize(objective_xgb, n_trials=30, show_progress_bar=True)

print(f'\n  Optimization complete in {(datetime.now() - xgb_start).total_seconds()/60:.1f} minutes')
print(f'  Best F1: {study_xgb.best_value:.4f}')
print(f'  Best params: {study_xgb.best_params}')

# Train final model
xgb_best_params = study_xgb.best_params
xgb_best_params.update({
    'scale_pos_weight': 774,
    'eval_metric': 'logloss',
    'use_label_encoder': False,
    'random_state': 42,
    'n_jobs': 4
})
xgb_model = XGBClassifier(**xgb_best_params)

# Train on SMOTE-ENN data (already created)
print('  Training final XGBoost...')
xgb_model.fit(X_train_balanced, y_train_balanced)

# Cross-validation
xgb_cv_results = perform_cv(
    XGBClassifier(**xgb_best_params),
    X_train_scaled, y_train, 'XGBoost'
)

# Evaluate
xgb_results = evaluate_model(xgb_model, X_train_balanced, y_train_balanced,
                             X_test_scaled, y_test, 'XGBoost')
xgb_results['cv'] = xgb_cv_results
xgb_results['cv_test_gap'] = xgb_cv_results['f1_mean'] - xgb_results['test']['f1']
xgb_results['best_params'] = xgb_best_params

print(f'\n  CV-Test Gap: {xgb_results["cv_test_gap"]:.4f} ({xgb_results["cv_test_gap"]*100:.1f}%)')

# Feature importance
xgb_results['feature_importance'] = {
    feat: float(imp)
    for feat, imp in zip(X_train.columns, xgb_model.feature_importances_)
}

# Permutation importance
print('\n  Computing permutation importance...')
perm_imp_xgb = permutation_importance(
    xgb_model, X_test_scaled.head(1000), y_test.head(1000),
    n_repeats=10, random_state=42, scoring='f1'
)
xgb_results['permutation_importance'] = {
    feat: float(imp)
    for feat, imp in zip(X_train.columns, perm_imp_xgb.importances_mean)
}

# ============================================================================
# 6. LOGISTIC REGRESSION
# ============================================================================

print('\n Logistic Regression...')

lr_model = LogisticRegression(
    C=0.1,
    penalty='l2',
    solver='saga',
    max_iter=1000,
    class_weight='balanced',
    random_state=42,
    n_jobs=4
)

print('  Training Logistic Regression...')
lr_model.fit(X_train_balanced, y_train_balanced)

# Cross-validation
lr_cv_results = perform_cv(
    LogisticRegression(C=0.1, penalty='l2', solver='saga', max_iter=1000,
                      class_weight='balanced', random_state=42, n_jobs=4),
    X_train_scaled, y_train, 'Logistic Regression'
)

# Evaluate
lr_results = evaluate_model(lr_model, X_train_balanced, y_train_balanced,
                            X_test_scaled, y_test, 'Logistic Regression')
lr_results['cv'] = lr_cv_results
lr_results['cv_test_gap'] = lr_cv_results['f1_mean'] - lr_results['test']['f1']

print(f'\n  CV-Test Gap: {lr_results["cv_test_gap"]:.4f} ({lr_results["cv_test_gap"]*100:.1f}%)')

# Coefficients
lr_results['coefficients'] = {
    feat: float(coef)
    for feat, coef in zip(X_train.columns, lr_model.coef_[0])
}

# ============================================================================
# 7. NEURAL NETWORK
# ============================================================================

print('\n Neural Network...')

# Build model
nn_model = keras.Sequential([
    layers.Dense(64, activation='relu', input_shape=(X_train_balanced.shape[1],)),
    layers.Dropout(0.3),
    layers.Dense(32, activation='relu'),
    layers.Dropout(0.3),
    layers.Dense(1, activation='sigmoid')
])

# Compile
nn_model.compile(
    optimizer=keras.optimizers.Adam(learning_rate=0.001),
    loss='binary_crossentropy',
    metrics=['accuracy']
)

# Class weights
fraud_weight = len(y_train_balanced) / (2 * y_train_balanced.sum())
class_weights = {0: 1.0, 1: fraud_weight}

print('  Training Neural Network...')
history = nn_model.fit(
    X_train_balanced, y_train_balanced,
    epochs=50,
    batch_size=256,
    class_weight=class_weights,
    validation_split=0.2,
    callbacks=[keras.callbacks.EarlyStopping(patience=10, restore_best_weights=True)],
    verbose=0
)

# Predictions
y_train_pred_proba_nn = nn_model.predict(X_train_balanced, verbose=0).flatten()
y_test_pred_proba_nn = nn_model.predict(X_test_scaled, verbose=0).flatten()

# Find optimal threshold
precisions, recalls, thresholds = precision_recall_curve(y_test, y_test_pred_proba_nn)
f1_scores = 2 * (precisions[:-1] * recalls[:-1]) / (precisions[:-1] + recalls[:-1] + 1e-10)
optimal_idx = np.argmax(f1_scores)
optimal_threshold = thresholds[optimal_idx]

print(f'  Optimal threshold: {optimal_threshold:.4f}')

y_train_pred_nn = (y_train_pred_proba_nn >= optimal_threshold).astype(int)
y_test_pred_nn = (y_test_pred_proba_nn >= optimal_threshold).astype(int)

# Calculate metrics
nn_results = {
    'model': 'Neural Network',
    'threshold': float(optimal_threshold),
    'train': {
        'f1': float(f1_score(y_train_balanced, y_train_pred_nn)),
        'precision': float(precision_score(y_train_balanced, y_train_pred_nn)),
        'recall': float(recall_score(y_train_balanced, y_train_pred_nn)),
        'mcc': float(matthews_corrcoef(y_train_balanced, y_train_pred_nn)),
        'roc_auc': float(roc_auc_score(y_train_balanced, y_train_pred_proba_nn))
    },
    'test': {
        'f1': float(f1_score(y_test, y_test_pred_nn)),
        'precision': float(precision_score(y_test, y_test_pred_nn)),
        'recall': float(recall_score(y_test, y_test_pred_nn)),
        'mcc': float(matthews_corrcoef(y_test, y_test_pred_nn)),
        'roc_auc': float(roc_auc_score(y_test, y_test_pred_proba_nn))
    },
    'confusion_matrix': confusion_matrix(y_test, y_test_pred_nn).tolist()
}

print('\n--- Neural Network Evaluation ---')
print(f'\n  Test Performance:')
print(f'    F1:        {nn_results["test"]["f1"]:.4f}')
print(f'    Precision: {nn_results["test"]["precision"]:.4f}')
print(f'    Recall:    {nn_results["test"]["recall"]:.4f}')
print(f'    MCC:       {nn_results["test"]["mcc"]:.4f}')
print(f'    ROC-AUC:   {nn_results["test"]["roc_auc"]:.4f}')

cm = nn_results['confusion_matrix']
print(f'\n  Confusion Matrix:')
print(f'    TN={cm[0][0]:,}  FP={cm[0][1]:,}')
print(f'    FN={cm[1][0]:,}  TP={cm[1][1]:,}')

# Note: CV not performed for NN due to complexity


# ============================================================================
# 7A. CORRELATION MATRIX ANALYSIS
# ============================================================================

print('\n[7A] Generating Correlation Matrix...')

# Compute correlation matrix
correlation_matrix = X_train.corr()

# Visualization
plt.figure(figsize=(20, 16))
mask = np.triu(np.ones_like(correlation_matrix, dtype=bool))
sns.heatmap(correlation_matrix, mask=mask, annot=True, fmt='.2f', 
            cmap='coolwarm', center=0, square=True,
            linewidths=0.5, cbar_kws={"shrink": 0.8})
plt.title('Feature Correlation Matrix - Experiment 3 (23 Features)\nUpper Triangle Masked',
          fontsize=16, fontweight='bold', pad=20)
plt.tight_layout()
plt.savefig('/Users/henriette/Desktop/Dissertation/Results/exp3_correlation_matrix.png',
           dpi=300, bbox_inches='tight')
plt.show()
print('✓ Saved: exp3_correlation_matrix.png')

# Identify high correlations (|r| > 0.80)
print('\n  High Correlations (|r| > 0.80):')
high_corr_pairs = []
for i in range(len(correlation_matrix.columns)):
    for j in range(i+1, len(correlation_matrix.columns)):
        corr_val = correlation_matrix.iloc[i, j]
        if abs(corr_val) > 0.80:
            high_corr_pairs.append({
                'Feature_1': correlation_matrix.columns[i],
                'Feature_2': correlation_matrix.columns[j],
                'Correlation': corr_val
            })
            print(f'    {correlation_matrix.columns[i]:25s} ↔ {correlation_matrix.columns[j]:25s}: r={corr_val:6.3f}')

# Save high correlation pairs
if high_corr_pairs:
    high_corr_df = pd.DataFrame(high_corr_pairs)
    high_corr_df = high_corr_df.sort_values('Correlation', key=abs, ascending=False)
    high_corr_df.to_csv('/Users/henriette/Desktop/Dissertation/Results/exp3_high_correlations.csv', 
                        index=False)
    print(f'\n  ✓ Found {len(high_corr_pairs)} high correlation pairs')
    print('  ✓ Saved: exp3_high_correlations.csv')
else:
    print('  No correlations > 0.80 found')

# ============================================================================
# 7B. ROC CURVES WITH GINI COEFFICIENT (SUPERVISOR'S FORMAT)
# ============================================================================

print('\n[7B] Generating ROC Curves with GINI coefficient...')

def gini_coefficient(y_true, y_pred_proba):
    """Calculate GINI coefficient from ROC-AUC"""
    fpr, tpr, _ = roc_curve(y_true, y_pred_proba)
    roc_auc_val = auc(fpr, tpr)
    gini = 100 * (2 * roc_auc_val - 1)
    return gini, fpr, tpr, roc_auc_val

# Get predictions for all models
models_for_roc = {
    'Random Forest': (rf_model, X_train_balanced, y_train_balanced, X_test_scaled, y_test),
    'XGBoost': (xgb_model, X_train_balanced, y_train_balanced, X_test_scaled, y_test),
    'Logistic Regression': (lr_model, X_train_balanced, y_train_balanced, X_test_scaled, y_test),
}

# Individual ROC curves for each model (Train vs Test)
for model_name, (model, X_tr, y_tr, X_te, y_te) in models_for_roc.items():
    
    # Get predictions
    if model_name == 'Neural Network':
        y_train_proba = nn_model.predict(X_train_balanced, verbose=0).flatten()
        y_test_proba = nn_model.predict(X_test_scaled, verbose=0).flatten()
    else:
        y_train_proba = model.predict_proba(X_tr)[:, 1]
        y_test_proba = model.predict_proba(X_te)[:, 1]
    
    # Calculate GINI
    train_gini, fpr_train, tpr_train, auc_train = gini_coefficient(y_tr, y_train_proba)
    test_gini, fpr_test, tpr_test, auc_test = gini_coefficient(y_te, y_test_proba)
    
    # Plot
    fig, ax = plt.subplots(figsize=(10, 7))
    
    # Test ROC
    ax.plot(fpr_test, tpr_test, color='green', linewidth=2.5,
           label=f'Test (GINI = {test_gini:.1f}%, AUC = {auc_test:.4f})')
    
    # Train ROC
    ax.plot(fpr_train, tpr_train, color='red', linewidth=2.5,
           label=f'Train (GINI = {train_gini:.1f}%, AUC = {auc_train:.4f})')
    
    # Random baseline
    ax.plot([0, 1], [0, 1], color='navy', lw=2, linestyle='--', label='Random (GINI = 0%)')
    
    ax.set_xlabel('False Positive Rate', fontsize=12)
    ax.set_ylabel('True Positive Rate', fontsize=12)
    ax.set_title(f'ROC Curve - {model_name}\n(Experiment 3: 23 Features, 5-Fold CV)',
                fontsize=14, fontweight='bold')
    ax.legend(loc="lower right", frameon=True, fontsize=11)
    ax.grid(alpha=0.3)
    
    plt.tight_layout()
    plt.savefig(f'/Users/henriette/Desktop/Dissertation/Results/exp3_roc_{model_name.lower().replace(" ", "_")}.png',
               dpi=300, bbox_inches='tight')
    plt.show()
    print(f'  ✓ Saved: exp3_roc_{model_name.lower().replace(" ", "_")}.png')
    print(f'    Train GINI: {train_gini:.1f}%, Test GINI: {test_gini:.1f}%')

# Combined ROC curve (all models on test set)
plt.figure(figsize=(10, 7))

# Random Forest
y_test_proba_rf = rf_model.predict_proba(X_test_scaled)[:, 1]
test_gini_rf, fpr_rf, tpr_rf, auc_rf = gini_coefficient(y_test, y_test_proba_rf)
plt.plot(fpr_rf, tpr_rf, linewidth=2.5, 
        label=f'Random Forest (GINI={test_gini_rf:.1f}%, AUC={auc_rf:.4f})')

# XGBoost
y_test_proba_xgb = xgb_model.predict_proba(X_test_scaled)[:, 1]
test_gini_xgb, fpr_xgb, tpr_xgb, auc_xgb = gini_coefficient(y_test, y_test_proba_xgb)
plt.plot(fpr_xgb, tpr_xgb, linewidth=2.5,
        label=f'XGBoost (GINI={test_gini_xgb:.1f}%, AUC={auc_xgb:.4f})')

# Logistic Regression
y_test_proba_lr = lr_model.predict_proba(X_test_scaled)[:, 1]
test_gini_lr, fpr_lr, tpr_lr, auc_lr = gini_coefficient(y_test, y_test_proba_lr)
plt.plot(fpr_lr, tpr_lr, linewidth=2.5,
        label=f'Logistic Regression (GINI={test_gini_lr:.1f}%, AUC={auc_lr:.4f})')

# Neural Network
y_test_proba_nn_roc = nn_model.predict(X_test_scaled, verbose=0).flatten()
test_gini_nn, fpr_nn, tpr_nn, auc_nn = gini_coefficient(y_test, y_test_proba_nn_roc)
plt.plot(fpr_nn, tpr_nn, linewidth=2.5,
        label=f'Neural Network (GINI={test_gini_nn:.1f}%, AUC={auc_nn:.4f})')

# Random baseline
plt.plot([0, 1], [0, 1], color='navy', lw=2, linestyle='--', label='Random (GINI = 0%)')

plt.xlabel('False Positive Rate', fontsize=12)
plt.ylabel('True Positive Rate', fontsize=12)
plt.title('ROC Curves Comparison - All Models\n(Experiment 3: 23 Features, Test Set)',
         fontsize=14, fontweight='bold')
plt.legend(loc="lower right", frameon=True, fontsize=10)
plt.grid(alpha=0.3)
plt.tight_layout()
plt.savefig('/Users/henriette/Desktop/Dissertation/Results/exp3_roc_all_models_comparison.png',
           dpi=300, bbox_inches='tight')
plt.show()
print('✓ Saved: exp3_roc_all_models_comparison.png')

# Store GINI results
gini_results = {
    'Random Forest': {'train': train_gini_rf, 'test': test_gini_rf},
    'XGBoost': {'train': train_gini_xgb, 'test': test_gini_xgb},
    'Logistic Regression': {'train': train_gini_lr, 'test': test_gini_lr},
    'Neural Network': {'train': test_gini_nn, 'test': test_gini_nn}  # NN only has test
}

# ============================================================================
# 7C. CONFUSION MATRIX HEATMAPS
# ============================================================================

print('\n[7C] Generating Confusion Matrix Heatmaps...')

fig, axes = plt.subplots(2, 2, figsize=(14, 12))

models_cms = [
    ('Random Forest', rf_results['confusion_matrix']),
    ('XGBoost', xgb_results['confusion_matrix']),
    ('Logistic Regression', lr_results['confusion_matrix']),
    ('Neural Network', nn_results['confusion_matrix'])
]

for idx, (model_name, cm) in enumerate(models_cms):
    ax = axes[idx // 2, idx % 2]
    
    # Create heatmap
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', ax=ax,
               xticklabels=['Legitimate', 'Fraud'],
               yticklabels=['Legitimate', 'Fraud'],
               cbar_kws={'label': 'Count'})
    
    # Calculate metrics for title
    TP = cm[1][1]
    FN = cm[1][0]
    FP = cm[0][1]
    TN = cm[0][0]
    
    detection_rate = (TP / (TP + FN) * 100) if (TP + FN) > 0 else 0
    false_alarm_rate = (FP / (FP + TN) * 100) if (FP + TN) > 0 else 0
    
    ax.set_title(f'{model_name}\nDetection: {detection_rate:.1f}% | False Alarms: {false_alarm_rate:.2f}%',
                fontsize=12, fontweight='bold')
    ax.set_ylabel('True Label', fontsize=11)
    ax.set_xlabel('Predicted Label', fontsize=11)

plt.suptitle('Confusion Matrices - Experiment 3 (23 Features)', 
            fontsize=14, fontweight='bold', y=1.00)
plt.tight_layout()
plt.savefig('/Users/henriette/Desktop/Dissertation/Results/exp3_confusion_matrices.png',
           dpi=300, bbox_inches='tight')
plt.show()
print('✓ Saved: exp3_confusion_matrices.png')

# ============================================================================
# 7D. PERMUTATION IMPORTANCE COMPARISON
# ============================================================================

print('\n[7D] Comparing Permutation Importance across models...')

# Create comparison dataframe
perm_imp_comparison = pd.DataFrame({
    'Feature': X_train.columns,
    'RF_PermImp': [rf_results['permutation_importance'][f] for f in X_train.columns],
    'XGB_PermImp': [xgb_results['permutation_importance'][f] for f in X_train.columns],
    'RF_BuiltIn': [rf_results['feature_importance'][f] for f in X_train.columns],
    'XGB_BuiltIn': [xgb_results['feature_importance'][f] for f in X_train.columns]
})

# Sort by RF permutation importance
perm_imp_comparison = perm_imp_comparison.sort_values('RF_PermImp', ascending=False)

# Plot top 15 features
top_n = 15
top_features = perm_imp_comparison.head(top_n)

fig, axes = plt.subplots(1, 2, figsize=(18, 8))

# Permutation Importance comparison
ax1 = axes[0]
x = np.arange(top_n)
width = 0.35
ax1.barh(x - width/2, top_features['RF_PermImp'], width, label='Random Forest', color='lightgreen')
ax1.barh(x + width/2, top_features['XGB_PermImp'], width, label='XGBoost', color='lightblue')
ax1.set_yticks(x)
ax1.set_yticklabels(top_features['Feature'])
ax1.set_xlabel('Permutation Importance', fontsize=12)
ax1.set_title('Permutation Importance Comparison\n(Top 15 Features)', 
             fontsize=13, fontweight='bold')
ax1.legend()
ax1.invert_yaxis()
ax1.grid(axis='x', alpha=0.3)

# Built-in Importance comparison
ax2 = axes[1]
ax2.barh(x - width/2, top_features['RF_BuiltIn'], width, label='Random Forest (Gini)', color='green')
ax2.barh(x + width/2, top_features['XGB_BuiltIn'], width, label='XGBoost (Gain)', color='blue')
ax2.set_yticks(x)
ax2.set_yticklabels(top_features['Feature'])
ax2.set_xlabel('Built-in Importance', fontsize=12)
ax2.set_title('Built-in Feature Importance Comparison\n(Top 15 Features)',
             fontsize=13, fontweight='bold')
ax2.legend()
ax2.invert_yaxis()
ax2.grid(axis='x', alpha=0.3)

plt.tight_layout()
plt.savefig('/Users/henriette/Desktop/Dissertation/Results/exp3_importance_comparison.png',
           dpi=300, bbox_inches='tight')
plt.show()
print('✓ Saved: exp3_importance_comparison.png')

# Save comparison CSV
perm_imp_comparison.to_csv('/Users/henriette/Desktop/Dissertation/Results/exp3_importance_comparison.csv',
                          index=False)
print('✓ Saved: exp3_importance_comparison.csv')

print('\n' + '='*80)
print('✓✓✓ ALL VISUALIZATIONS COMPLETE!')
print('='*80)




# ============================================================================
# 8. COMPARISON AND VISUALIZATION
# ============================================================================

print('\n[7/8] Creating comparison visualizations...')

# Summary table
summary_data = {
    'Model': ['Random Forest', 'XGBoost', 'Logistic Regression', 'Neural Network'],
    'Test F1': [
        rf_results['test']['f1'],
        xgb_results['test']['f1'],
        lr_results['test']['f1'],
        nn_results['test']['f1']
    ],
    'Test Precision': [
        rf_results['test']['precision'],
        xgb_results['test']['precision'],
        lr_results['test']['precision'],
        nn_results['test']['precision']
    ],
    'Test Recall': [
        rf_results['test']['recall'],
        xgb_results['test']['recall'],
        lr_results['test']['recall'],
        nn_results['test']['recall']
    ],
    'Test MCC': [
        rf_results['test']['mcc'],
        xgb_results['test']['mcc'],
        lr_results['test']['mcc'],
        nn_results['test']['mcc']
    ],
    'CV F1': [
        rf_cv_results['f1_mean'],
        xgb_cv_results['f1_mean'],
        lr_cv_results['f1_mean'],
        'N/A'
    ],
    'CV-Test Gap': [
        rf_results['cv_test_gap'],
        xgb_results['cv_test_gap'],
        lr_results['cv_test_gap'],
        'N/A'
    ]
}

summary_df = pd.DataFrame(summary_data)
print('\n' + '='*80)
print('EXPERIMENT 3 RESULTS SUMMARY (23 Features, No Selection)')
print('='*80)
print(summary_df.to_string(index=False))
print('='*80)

# Visualization
fig, axes = plt.subplots(2, 2, figsize=(16, 12))

# 1. F1 Score Comparison
ax1 = axes[0, 0]
models = summary_data['Model']
f1_scores = summary_data['Test F1']
bars = ax1.bar(models, f1_scores, color=['#2ecc71', '#3498db', '#e74c3c', '#f39c12'])
ax1.set_ylabel('F1 Score', fontsize=12)
ax1.set_title('Test F1 Score Comparison\n(23 Features, No Selection)', fontsize=13, fontweight='bold')
ax1.set_ylim([0, max(f1_scores) * 1.2])
for bar, score in zip(bars, f1_scores):
    height = bar.get_height()
    ax1.text(bar.get_x() + bar.get_width()/2., height,
            f'{score:.4f}', ha='center', va='bottom', fontsize=11)
ax1.grid(axis='y', alpha=0.3)
plt.setp(ax1.xaxis.get_majorticklabels(), rotation=45, ha='right')

# 2. Precision vs Recall
ax2 = axes[0, 1]
precisions = summary_data['Test Precision']
recalls = summary_data['Test Recall']
x = np.arange(len(models))
width = 0.35
ax2.bar(x - width/2, precisions, width, label='Precision', color='skyblue')
ax2.bar(x + width/2, recalls, width, label='Recall', color='orange')
ax2.set_ylabel('Score', fontsize=12)
ax2.set_title('Precision vs Recall\n(23 Features, No Selection)', fontsize=13, fontweight='bold')
ax2.set_xticks(x)
ax2.set_xticklabels(models)
ax2.legend()
ax2.grid(axis='y', alpha=0.3)
plt.setp(ax2.xaxis.get_majorticklabels(), rotation=45, ha='right')

# 3. CV-Test Gap (Overfitting Analysis)
ax3 = axes[1, 0]
gap_models = [m for m, g in zip(models, summary_data['CV-Test Gap']) if g != 'N/A']
gaps = [g for g in summary_data['CV-Test Gap'] if g != 'N/A']
bars = ax3.bar(gap_models, gaps, color=['#e74c3c' if g > 0.6 else '#f39c12' if g > 0.4 else '#2ecc71' 
                                        for g in gaps])
ax3.axhline(y=0.6, color='red', linestyle='--', alpha=0.5, label='Severe Overfitting (>0.6)')
ax3.set_ylabel('CV-Test F1 Gap', fontsize=12)
ax3.set_title('Overfitting Analysis (CV-Test Gap)\n(23 Features, No Selection)', 
             fontsize=13, fontweight='bold')
ax3.legend()
ax3.grid(axis='y', alpha=0.3)
for bar, gap in zip(bars, gaps):
    height = bar.get_height()
    ax3.text(bar.get_x() + bar.get_width()/2., height,
            f'{gap:.4f}', ha='center', va='bottom', fontsize=11)
plt.setp(ax3.xaxis.get_majorticklabels(), rotation=45, ha='right')

# 4. Feature Importance (RF - top 10)
ax4 = axes[1, 1]
rf_imp_sorted = sorted(rf_results['feature_importance'].items(), key=lambda x: x[1], reverse=True)
top_10_features = [f for f, _ in rf_imp_sorted[:10]]
top_10_importance = [imp for _, imp in rf_imp_sorted[:10]]
ax4.barh(top_10_features, top_10_importance, color='lightgreen')
ax4.set_xlabel('Importance', fontsize=12)
ax4.set_title('Top 10 Features - Random Forest\n(23 Features, No Selection)', 
             fontsize=13, fontweight='bold')
ax4.invert_yaxis()
ax4.grid(axis='x', alpha=0.3)

plt.tight_layout()
plt.savefig('/Users/henriette/Desktop/Dissertation/Results/exp3_comparison_23features.png',
           dpi=300, bbox_inches='tight')
plt.show()
print('✓ Saved: exp3_comparison_23features.png')

# ============================================================================
# 9. SAVE RESULTS
# ============================================================================

print('\n[8/8] Saving results...')

# Compile all results
final_results = {
    'experiment': 'Experiment 3: Unselected Feature Engineering',
    'features': list(X_train.columns),
    'n_features': len(X_train.columns),
    'timestamp': datetime.now().isoformat(),
    'models': {
        'random_forest': rf_results,
        'xgboost': xgb_results,
        'logistic_regression': lr_results,
        'neural_network': nn_results
    },
    'summary': summary_data,
    'comparison_to_exp2': {
        'exp2_baseline_f1': 0.3074,
        'best_model': max([(m, r['test']['f1']) for m, r in {
            'Random Forest': rf_results,
            'XGBoost': xgb_results,
            'Logistic Regression': lr_results,
            'Neural Network': nn_results
        }.items()], key=lambda x: x[1]),
        'improvement_vs_baseline': max([
            rf_results['test']['f1'],
            xgb_results['test']['f1'],
            lr_results['test']['f1'],
            nn_results['test']['f1']
        ]) - 0.3074
    }
}

# Save to JSON
with open('/Users/henriette/Desktop/Dissertation/Results/exp3_comprehensive_results.json', 'w') as f:
    json.dump(final_results, f, indent=2)

print(' Saved: exp3_comprehensive_results.json')

# Save summary CSV
summary_df.to_csv('/Users/henriette/Desktop/Dissertation/Results/exp3_summary.csv', index=False)
print(' Saved: exp3_summary.csv')

# Save feature importance
rf_imp_df = pd.DataFrame(rf_results['feature_importance'].items(), 
                         columns=['Feature', 'RF_Importance'])
rf_imp_df = rf_imp_df.sort_values('RF_Importance', ascending=False)
rf_imp_df.to_csv('/Users/henriette/Desktop/Dissertation/Results/exp3_feature_importance_rf.csv', 
                 index=False)
print(' Saved: exp3_feature_importance_rf.csv')

xgb_imp_df = pd.DataFrame(xgb_results['feature_importance'].items(),
                          columns=['Feature', 'XGB_Importance'])
xgb_imp_df = xgb_imp_df.sort_values('XGB_Importance', ascending=False)
xgb_imp_df.to_csv('/Users/henriette/Desktop/Dissertation/Results/exp3_feature_importance_xgb.csv',
                  index=False)
print(' Saved: exp3_feature_importance_xgb.csv')

print('\n' + '='*80)
print('✓✓✓ EXPERIMENT 3 COMPLETE!')
print('='*80)
print(f'\nBest Model: {final_results["comparison_to_exp2"]["best_model"][0]}')
print(f'Best F1: {final_results["comparison_to_exp2"]["best_model"][1]:.4f}')
print(f'Improvement vs Exp 2 baseline: {final_results["comparison_to_exp2"]["improvement_vs_baseline"]:.4f}')
print('\nAll results saved to /Users/henriette/Desktop/Dissertation/Results/')
print('='*80)