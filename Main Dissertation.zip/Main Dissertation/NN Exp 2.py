
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import (classification_report, confusion_matrix, 
                             f1_score, matthews_corrcoef, roc_auc_score, roc_curve)
from sklearn.model_selection import cross_val_score
from imblearn.combine import SMOTEENN
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers
from tensorflow.keras.callbacks import EarlyStopping
import time
import warnings
warnings.filterwarnings('ignore')

print('='*70)
print("EXPERIMENT 2: NEURAL NETWORK - PRODUCTION FEATURES")
print("5 Features - NO Temporal Leakage")
print('='*70)


# LOAD DATA
X_train_full = pd.read_csv('/Users/henriette/Desktop/Dissertation/Data/X_train_exp1.csv')
X_test_full = pd.read_csv('/Users/henriette/Desktop/Dissertation/Data/X_test_exp1.csv')
y_train = pd.read_csv('/Users/henriette/Desktop/Dissertation/Data/y_train_exp1.csv').squeeze()
y_test = pd.read_csv('/Users/henriette/Desktop/Dissertation/Data/y_test_exp1.csv').squeeze()

print(f' Original data loaded: {X_train_full.shape[0]:,} train, {X_test_full.shape[0]:,} test')

# Select production features only
production_features = ['amount', 'type_TRANSFER', 'type_PAYMENT', 'type_CASH_OUT', 'type_CASH_IN']
X_train = X_train_full[production_features].copy()
X_test = X_test_full[production_features].copy()

print(f' Production features selected: {len(production_features)} features')
print(f'  Features: {production_features}')


# Applying MinMaxScaler

scaler = MinMaxScaler()
X_train_scaled = pd.DataFrame(scaler.fit_transform(X_train), columns=X_train.columns)
X_test_scaled = pd.DataFrame(scaler.transform(X_test), columns=X_test.columns)

print(' Scaled')


# Applying SMOTE-ENN

start_smote = time.time()

smote_enn = SMOTEENN(random_state=42, n_jobs=-1)
X_train_balanced, y_train_balanced = smote_enn.fit_resample(X_train_scaled, y_train)

print(f' SMOTE-ENN: {time.time()-start_smote:.1f}s')
print(f'  Original: {len(X_train_scaled):,} samples')
print(f'  Balanced: {len(X_train_balanced):,} samples')
print(f'  Class distribution: {np.bincount(y_train_balanced)}')


# Building Neural Network

# Clear any previous models
keras.backend.clear_session()

# Build model
model = keras.Sequential([
    layers.Dense(64, activation='relu', input_shape=(X_train_balanced.shape[1],)),
    layers.Dropout(0.3),
    layers.Dense(32, activation='relu'),
    layers.Dropout(0.3),
    layers.Dense(16, activation='relu'),
    layers.Dense(1, activation='sigmoid')
])

model.compile(
    optimizer='adam',
    loss='binary_crossentropy',
    metrics=['accuracy', tf.keras.metrics.AUC(name='auc')]
)

print(' Model built')
print(f'  Architecture: {X_train_balanced.shape[1]} → 64 → 32 → 16 → 1')
print(f'  Parameters: {model.count_params():,}')


# Training Neural Network

# Early stopping
early_stop = EarlyStopping(
    monitor='val_loss',
    patience=5,
    restore_best_weights=True,
    verbose=0
)

# Class weights (even though we used SMOTEENN, this helps)
class_weight = {0: 1, 1: 1}  # Already balanced by SMOTEENN

start_train = time.time()

history = model.fit(
    X_train_balanced, 
    y_train_balanced,
    epochs=30,
    batch_size=512,
    validation_split=0.2,
    class_weight=class_weight,
    callbacks=[early_stop],
    verbose=0
)

print(f' Training: {time.time()-start_train:.1f}s')
print(f'  Epochs completed: {len(history.history["loss"])}')
print(f'  Final train loss: {history.history["loss"][-1]:.4f}')
print(f'  Final val loss: {history.history["val_loss"][-1]:.4f}')

# Making predictions

# Predictions
y_train_proba = model.predict(X_train_balanced, verbose=0).flatten()
y_test_proba = model.predict(X_test_scaled, verbose=0).flatten()

# Find optimal threshold
thresholds = np.arange(0.1, 1.0, 0.01)
f1_scores_train = []

for thresh in thresholds:
    y_train_pred_temp = (y_train_proba >= thresh).astype(int)
    f1 = f1_score(y_train_balanced, y_train_pred_temp)
    f1_scores_train.append(f1)

optimal_threshold = thresholds[np.argmax(f1_scores_train)]
print(f' Optimal threshold: {optimal_threshold:.4f}')

# Apply threshold
y_train_pred = (y_train_proba >= optimal_threshold).astype(int)
y_test_pred = (y_test_proba >= optimal_threshold).astype(int)

print('Predictions complete')

# Calculating metrics

# Confusion matrices
cm_train = confusion_matrix(y_train_balanced, y_train_pred)
cm_test = confusion_matrix(y_test, y_test_pred)

# Metrics
train_f1 = f1_score(y_train_balanced, y_train_pred)
test_f1 = f1_score(y_test, y_test_pred)

train_mcc = matthews_corrcoef(y_train_balanced, y_train_pred)
test_mcc = matthews_corrcoef(y_test, y_test_pred)

train_auc = roc_auc_score(y_train_balanced, y_train_proba)
test_auc = roc_auc_score(y_test, y_test_proba)

# Classification report
test_report = classification_report(y_test, y_test_pred, output_dict=True)

print('\n' + '='*70)
print('EXPERIMENT 2: NEURAL NETWORK (PRODUCTION FEATURES)')
print('='*70)

print(f'\nTrain:  F1={train_f1:.4f}, MCC={train_mcc:.4f}, AUC={train_auc:.4f}')
print(f'Test:   F1={test_f1:.4f}, MCC={test_mcc:.4f}, AUC={test_auc:.4f}')
print(f'\nPrecision: {test_report["1"]["precision"]:.4f}')
print(f'Recall:    {test_report["1"]["recall"]:.4f}')

print('\nConfusion Matrix (Test):')
print(f'  TN={cm_test[0,0]:,}, FP={cm_test[0,1]:,}')
print(f'  FN={cm_test[1,0]:,}, TP={cm_test[1,1]:,}')

# Compare to Exp 1
print('\n' + '-'*70)
print('COMPARISON TO EXPERIMENT 1:')
print('-'*70)
print('EXP 1 (8 features): Test F1=0.7079, MCC=0.7232, AUC=0.9594')
print(f'EXP 2 (5 features): Test F1={test_f1:.4f}, MCC={test_mcc:.4f}, AUC={test_auc:.4f}')
print(f'PERFORMANCE DROP:   ΔF1={test_f1-0.7079:.4f} ({((test_f1-0.7079)/0.7079)*100:.1f}%)')
print('='*70)


#  Creating visualizations

# ROC Curve
fpr_train, tpr_train, _ = roc_curve(y_train_balanced, y_train_proba)
fpr_test, tpr_test, _ = roc_curve(y_test, y_test_proba)

gini_train = 2 * train_auc - 1
gini_test = 2 * test_auc - 1

plt.figure(figsize=(10, 8))
plt.plot(fpr_test, tpr_test, 'g-', linewidth=2, 
         label=f'Test (GINI = {gini_test*100:.1f}%, AUC = {test_auc:.4f})')
plt.plot(fpr_train, tpr_train, 'r-', linewidth=2, 
         label=f'Train (GINI = {gini_train*100:.1f}%, AUC = {train_auc:.4f})')
plt.plot([0, 1], [0, 1], 'b--', linewidth=2, label='Random (GINI = 0%)')
plt.xlim([-0.01, 1.01])
plt.ylim([-0.01, 1.01])
plt.xlabel('False Positive Rate', fontsize=12)
plt.ylabel('True Positive Rate', fontsize=12)
plt.title('ROC Curve - Neural Network (Experiment 2: Production Features Only)', 
          fontsize=14, fontweight='bold')
plt.legend(loc='lower right', fontsize=11)
plt.grid(alpha=0.3)
plt.tight_layout()
plt.savefig('/Users/henriette/Desktop/Dissertation/Results/roc_nn_exp2.png', 
            dpi=300, bbox_inches='tight')
plt.show()
print(' ROC curve saved')

# Confusion Matrix
fig, axes = plt.subplots(1, 2, figsize=(14, 6))

# Test confusion matrix
cm_test_pct = cm_test.astype('float') / cm_test.sum(axis=1)[:, np.newaxis] * 100
sns.heatmap(cm_test, annot=True, fmt='d', cmap='Greens', ax=axes[0], 
            cbar=False, square=True, linewidths=2)
axes[0].set_title('Neural Network Exp 2\nConfusion Matrix (Counts)', 
                  fontsize=13, fontweight='bold')
axes[0].set_ylabel('Actual', fontsize=11)
axes[0].set_xlabel('Predicted', fontsize=11)
axes[0].set_xticklabels(['Legitimate', 'Fraud'])
axes[0].set_yticklabels(['Legitimate', 'Fraud'])

# Add percentages as text
for i in range(2):
    for j in range(2):
        axes[0].text(j+0.5, i+0.7, f'({cm_test_pct[i,j]:.1f}%)', 
                    ha='center', va='center', fontsize=10, color='darkgreen')

# Comparison bar chart
comparison_data = pd.DataFrame({
    'Experiment': ['Exp 1\n(8 features)', 'Exp 2\n(5 features)'],
    'F1-Score': [0.7079, test_f1],
    'Recall': [0.6830, test_report["1"]["recall"]]
})

x = np.arange(len(comparison_data))
width = 0.35

axes[1].bar(x - width/2, comparison_data['F1-Score'], width, 
           label='F1-Score', color='skyblue', edgecolor='black')
axes[1].bar(x + width/2, comparison_data['Recall'], width, 
           label='Recall', color='lightcoral', edgecolor='black')

axes[1].set_ylabel('Score', fontsize=11)
axes[1].set_title('Neural Network: Exp 1 vs Exp 2\nPerformance Comparison', 
                  fontsize=13, fontweight='bold')
axes[1].set_xticks(x)
axes[1].set_xticklabels(comparison_data['Experiment'])
axes[1].legend()
axes[1].set_ylim([0, 1])
axes[1].grid(axis='y', alpha=0.3)

# Add value labels on bars
for i, (f1, rec) in enumerate(zip(comparison_data['F1-Score'], comparison_data['Recall'])):
    axes[1].text(i - width/2, f1 + 0.02, f'{f1:.3f}', ha='center', fontsize=10, fontweight='bold')
    axes[1].text(i + width/2, rec + 0.02, f'{rec:.3f}', ha='center', fontsize=10, fontweight='bold')

plt.suptitle('Neural Network - Experiment 2 (5 Production Features)', 
             fontsize=15, fontweight='bold', y=1.02)
plt.tight_layout()
plt.savefig('/Users/henriette/Desktop/Dissertation/Results/confusion_comparison_nn_exp2.png', 
            dpi=300, bbox_inches='tight')
plt.show()
print('Confusion matrix saved')


# Saving results
# Save metrics
metrics_summary = {
    'model': 'Neural_Network',
    'experiment': 'Exp2_Production',
    'features': 5,
    'train_f1': train_f1,
    'test_f1': test_f1,
    'train_mcc': train_mcc,
    'test_mcc': test_mcc,
    'train_auc': train_auc,
    'test_auc': test_auc,
    'test_precision': test_report["1"]["precision"],
    'test_recall': test_report["1"]["recall"],
    'threshold': optimal_threshold,
    'frauds_caught': int(cm_test[1,1]),
    'frauds_total': int(cm_test[1,0] + cm_test[1,1]),
    'false_alarms': int(cm_test[0,1])
}

pd.DataFrame([metrics_summary]).to_csv(
    '/Users/henriette/Desktop/Dissertation/Results/exp2_nn_metrics.csv', 
    index=False
)

print(' Metrics saved')

print('\n' + '='*70)
print('NEURAL NETWORK (EXP 2) COMPLETE')
print('='*70)

